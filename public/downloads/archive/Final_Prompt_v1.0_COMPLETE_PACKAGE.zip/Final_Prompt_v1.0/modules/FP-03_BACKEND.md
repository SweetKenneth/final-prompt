# FP-03 — Backend / API Production Audit and Remediation

**Trigger:** routes, server actions, middleware, services, workers, databases, serverless handlers, integrations, background jobs or APIs actually exist. **Implementation authorized:** safe targeted changes only.

## Universal directive

Audit all relevant backend code and infrastructure configuration; implement real, safe, concrete fixes. Use as many focused multi-turn phases as needed, but checkpoint each phase and avoid wasteful repeats. Do not invent an auth stack, database, queue, API, cloud provider, or runtime. Keep existing architecture and behavior except to repair evidenced faults.

## 1. Backend correctness and HTTP/API behavior

Enumerate route/method/status/response contracts, handlers, actions, middleware and utility paths. Fix incorrect response codes, bad redirects, inconsistent shapes, unhandled rejections, unchecked optional values, swallowed errors, malformed upstream responses, missing authorization, broken content negotiation and incorrect pagination. For each endpoint test missing/malformed input, nonexistent ID, empty result, upstream/database/storage failure, timeout, unauthorized and forbidden access. Prefer predictable typed contracts and meaningful non-sensitive errors. Respect idempotency and resource lifecycle semantics.

## 2. Validation and input safety

Validate at the trust boundary: emails, URLs, IDs, slugs, enums, lengths, pagination, query strings, JSON schema, file metadata, multipart bodies, numeric limits and Unicode/encoding. Use canonical parsing and allowlists where needed; don't blindly mutate user content through aggressive sanitization. Constrain resource use and reject oversized or unexpected payloads. Keep backend authoritative even if frontend validates. Add negative-path tests.

## 3. Data contracts, response consistency and disclosure

Align frontend/backend DTOs, optionality, error envelopes, versioning, filtering, sorting and pagination; do not break existing clients without compatibility plan. Hide stack traces, query internals, filesystem paths, raw cloud/service failures and sensitive identifiers. Ensure success and error semantics are stable and observability retains only redacted details.

## 4. Performance and async behavior

Measure repeated queries, N+1 calls, oversized results, excessive serialization, unnecessary sequential awaits, blocking operations, connection pool pressure, duplicate work, missing timeouts and unbounded loops. Apply batching, caching, indexing, concurrency limits and memoization only where they preserve correctness and provide measurable improvement. Ensure cancellation/time budgets when supported. Avoid introducing new infrastructure for marginal gains.

## 5. Reliability and resilience

Handle external API outages, retries, storage/DB failures, partial success, webhook errors, background job retries and service timeouts. Require retry backoff/jitter where appropriate; make side effects idempotent; prevent double submit/double delete/double charge. Verify cron/queue task ownership, replay protection, dead-letter or quarantine handling only when those systems exist. Remove unsafe production debug paths and silent dangerous fallbacks.

## 6. Security/privacy boundaries

Review hardcoded secrets, credentials, logs, cookie attributes, session invalidation, CSRF when applicable, rate limiting, CORS, redirects, authentication and object-level authorization, admin isolation, file upload content/size/type/path checks, server-side environment variable exposure, unsafe serialization and sensitive errors. Work with FP-09 for deeper tests; patch only owned server files and demonstrate denied cross-user access where relevant.

## 7. Database and storage

Confirm query correctness, ownership filtering, parameterized access, row permissions, indexes, bounded query limits, safe writes/updates/deletes, conflict handling and empty states. Guard against unscoped destructive statements and private object URLs. Coordinate migrations and restore planning with FP-10; never alter production data without scoped permission.

## 8. Email, contact, webhooks and integrations

Audit forms, lead and inquiry flows, support messages, delivery retries, signature verification, duplicate webhook events, spam prevention, callback URLs, third-party response validation and outbound safety. Use FP-16 as specialized owner of integration semantics when needed. Do not send real email or trigger real payments in tests.

## 9. Logging, monitoring and error handling

Use structured log levels and contextual identifiers with no credentials/PII; avoid noisy unbounded logs. Verify errors are actionable, do not cause process-wide crashes in catchable paths, and show appropriate customer messages. Coordinate centralized runtime signals with FP-12.

## 10. Code maintainability

Remove demonstrably dead handlers, duplicate utilities, unused imports/types, temporary files, obsolete debug/mock-only logic, and contradictory paths only after confirming not used by runtime, generated code, tests or deployment. Improve naming/type precision while preserving conventions. Avoid unnecessary dependencies and abstractions.

## 11. Deployment/runtime compatibility

Inspect actual environment variable usage, build/runtime flags, asset paths, server/client boundaries, serverless/edge restrictions, cold starts and startup behavior. Keep environment-specific config safe. Do not assume a production host or change live services without authorization. Coordinate with FP-11.

## 12. Build, test and final verification

Run only supported commands with logged exit codes: install (if necessary/authorized), lint, typecheck, unit/integration tests and production build. Test critical API paths, identity/authorization, form submits and mocked/staging integrations. Record what couldn't be tested due to missing credentials, environment, network, or fixtures. Compare before and after; remediate regressions introduced by the patch.

## Deliverable

Report high-priority defects fixed; API/validation/security, performance, reliability, database, deployment and maintainability changes; file-level diff list; exact commands/results; unresolved risks and follow-ups. Every claim 'fixed' requires the revision and at least one relevant verification reference.
