# FP-15 — Business Logic, Payments, Subscriptions and Entitlement Integrity

**Trigger:** actual money flows, subscriptions, metered API, credits, pricing, discounts, licensing, quotas, invitations, marketplace transactions or privileged entitlements. Otherwise NOT_APPLICABLE.

1. **Business rules and authority:** map prices, taxes (where configured), discounts, credits, commissions, refunds, thresholds, role gates, trials and entitlement states to the actual business specification. Identify systems of record and conflicting frontend vs backend calculations; server must authorize money-changing outcomes.
2. **Payments and idempotency:** inspect checkout creation, asynchronous payment webhooks, signature verification, duplicate events, out-of-order events, retries, partial failure, payment state reconciliation, refund/chargeback paths and stale checkout pages. Never trigger real charges/refunds or send real receipts without scoped approval.
3. **Subscriptions and access:** verify upgrade/downgrade, trial expiration, renewals, cancellation, grace periods, expired seats/tokens, capacity/credit counters, entitlement revocation and role boundaries. Tests must include bypass attempts via direct API requests and inconsistent webhook order.
4. **Double-spend and concurrency:** inspect atomic usage decrement, reservation/commit/cancel model, concurrent requests, optimistic locking, repeated purchase, coupon redemption and daily/monthly quota reset. Protect users from duplicate destructive or financial actions.
5. **Unit economics and abuse:** measure costs per paid operation, cap paid API usage and prevent adversarial quota evasion or cost explosions. Do not assume provider features or prices; inspect actual docs/config.
6. **Disputes, privacy and accounting integration:** verify stored records support reconciliation and customer support without exposing payment credentials. Do not invent PCI compliance, accounting correctness or legal payment terms.
7. **Acceptance tests:** use mocked sandbox/test payment credentials or authorized staging; check statuses, asynchronous transitions, 0/1/N duplicate events, refunds/cancellations and permission violations. Mark production-provider behavior unverified unless observed with permission.

**Deliverable:** state-transition table, money/entitlement defect log, repairs, reproducible tests, reconciliation exceptions and human approval needs. An unresolved P0/P1 payment-integrity failure blocks release.
