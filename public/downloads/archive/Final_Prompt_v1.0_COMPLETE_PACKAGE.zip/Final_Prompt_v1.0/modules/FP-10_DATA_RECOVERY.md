# FP-10 — Data Integrity, Storage, Migrations and Recovery

**Trigger:** relational/nonrelational database, local persisted state, blob/object storage, search index, caches as source of truth, or any user data persistence.

## Inventory and data classification

Identify owners of truth, schemas, tenancy keys, indexes, retention and deletion rules, encryption boundaries, consistency/replication model, backups, migration system, upload retention and environment separation. Never assume databases are present simply because the app exists.

## Query and data integrity

Test ownership and authorization filters for all CRUD paths; enforce constraints, valid transitions, uniqueness, referential integrity and optimistic/transactional safety where useful. Protect against unbounded reads/writes, mass assignment, unintended cascades, concurrency races, partial writes, double-applied event streams and N+1 anomalies. Fix with small typed changes coordinated with API/client expectations.

## Migration discipline

Inspect current version and migration history. Make migrations forward-compatible and repeatable; use expand-and-contract when needed; detect table locks, backfills, downtime risk, irreversible transforms and inconsistent deployments. Never apply changes directly to customer production data without explicit approval and backup/rollback evidence. Do not invent 'rollback' for irreversible deletion: propose restore and recovery paths.

## Backups, restores and durability

Verify actual backup configuration, retention, security, restore procedures, offsite/isolation properties and point-in-time objectives where promised. A backup file existing is not proof of recoverability. Prefer restore tests into isolated storage with synthetic/anonymized content and explicit authorization; check integrity and application compatibility. If restoration cannot be tested, label it UNVERIFIED and potential release blocker based on criticality. Identify RPO/RTO as requirements only when agreed; do not manufacture guarantees.

## File storage and privacy

Validate upload paths, MIME/sniffed types where needed, quotas, public/private access, signed URL expiry, lifecycle cleanup and unauthorized direct-object access. Check data export/delete and record retention, synchronization correctness and orphan files. Avoid logging payloads or private object URLs.

## Verification and delivery

Tests for valid/invalid writes, duplicate writes, ownership isolation, migration dry-run, rollback/fallback, backup/restore where authorized, consistency after failure injection in test environment. Record pre/post schema revisions, changes, executed commands and missing production evidence. Data deletion, large backfills, schema drops and irreversible transformations require per-action approval.
