# FP-11 — Infrastructure, Build, CI/CD and Software Supply Chain

**Trigger:** deployment or distribution exists. **Scope:** environment config, build reproducibility, CI permission model, dependency integrity, deploy/rollback plan.

1. **Environment map:** distinguish dev/test/staging/production; runtimes, regions, host constraints, DNS, TLS, build/runtime variables, secret injection, asset URLs, workers/edge/serverless restrictions. Do not invent a host. Verify supported platform APIs and resource limits.
2. **Reproducible build:** audit package manager, lockfiles, pinned toolchains, deterministic installations, cache trust, binary/platform compatibility, build scripts, generated artifacts and tests. Avoid arbitrary upgrading of major dependencies without evidence and compatibility tests.
3. **Dependency/supply-chain posture:** identify vulnerable/unmaintained dependencies, direct/transitive risk, provenance, lockfile drift, installer hooks, third-party scripts, licenses/NOTICE, signed release requirements where used. Triage advisories by reachable impact; no unsupported claims from a stale scanner.
4. **CI/CD safety:** inspect protected branches, pull-request trust, external contributions, workflow permissions, secrets exposure in logs/artifacts, runner isolation, supply-chain attacks, PR approval rules, deploy ownership, environment scopes and manual gates. Use least privilege for build and deployment credentials.
5. **Infrastructure-as-code/config:** check stale configs, insecure defaults, public buckets, network exposure, IAM privileges, misconfigured CORS/security headers, staging leaks, cron schedules, missing health probes and unsafe autoscale/cost defaults. Avoid infrastructure rewrites or cost-generating services without permission.
6. **Deployment discipline:** define preflight checks, artifact integrity, migration order, maintenance requirements, canary/blue-green feasibility, health rollback triggers, feature flags and restore plans. No auto-deployment to live service without explicit authorization.
7. **Cross-environment compatibility:** test cold-start/edge/node/runtime restrictions, background tasks and file system assumptions. Separate dev-only helpers from production artifacts.
8. **Verification:** run available lint/typecheck/tests/build/package checks; inspect CI configuration; exercise deploy dry-runs in safe environments if allowed. Record exact commands, environment, revision, results, and risk of changing build infrastructure.

**Output:** manifest of actual runtime/deployment surfaces, patched build/CI files, vulnerability and license triage, deployment/rollback plan, evidence and unresolved issues. Use NIST SSDF concepts as guidance, not as a claim of NIST certification.
