# FP-09 — Security Hardening, Threat Modeling and Abuse Prevention

**Trigger:** all software; test subset according to actual trust surfaces. **Reference:** OWASP ASVS stable 5.0.0 for applicable web controls and NIST SSDF for lifecycle process, without claiming compliance/certification.

## 1. Scope and threat model

Map assets, privileged roles, attack entry points, external systems, tenants, authentication/session boundaries, secrets, data sensitivity, supply chain and business-abuse incentives. Record likely attackers and plausible attacks. Separate production/staging/local resources; obtain explicit scope before active scans/fuzz/load/security testing of any network target. Never use destructive payloads or exfiltrate secrets.

## 2. Identity, session and authorization

Trace authn/authz separately: login, registration, logout, reset, MFA/passkeys if used, token/session creation, renewal, expiry, revocation, step-up, cookies, CSRF exposure, password handling, account recovery, device/session invalidation, privilege boundaries, admin functions, object-level and function-level access controls, tenant isolation, predictable resource IDs and indirect disclosure. Generate safe negative tests (user A cannot read/write user B; low role cannot perform privileged action). Ensure access checks on every server-side side effect, not just UI hiding.

## 3. Input, output and injection defense

Audit SQL/NoSQL/command/template/HTML/JS injection, unsafe deserialization, path traversal, prototype pollution where relevant, user-controlled redirects, SSRF, XML parsing, file upload execution, headers and request smuggling surface if applicable. Favor parameterized queries, contextual output encoding, allowlisted protocols/hosts, content security policy based on observed frontend needs, safe file parsing/storage, bounds on uploads/inputs. Avoid breaking legitimate content through indiscriminate input rewriting.

## 4. Secrets and cryptography

Scan authorized source/config/history and logs for keys/tokens/passwords with redacted evidence, verify server-side protection, vault/secret management where available, key rotation design, random generation, TLS configuration, encryption-in-transit/at-rest requirements and expiry. Exposed real secrets require incident escalation and explicit owner-coordinated rotation; never silently rotate or reveal them. Avoid homemade cryptography.

## 5. Network/platform and supply-chain security

Review CORS with credentials, security headers, origin/host validation, DNS/webhook callbacks, serverless permission limits, storage ACLs, buckets, IAM, container privilege, CI tokens, dependency provenance, malicious package updates and third-party script trust. Coordinate infrastructure fixes with FP-11.

## 6. Browser-specific safety

Inspect XSS sinks, DOM injection, CSP compatibility, service worker cache exposure, token storage, embedded third parties, clickjacking protection and unsafe postMessage/origin checks. `target=_blank` should use safe opener semantics. Avoid client-side secrets.

## 7. Abuse, fraud and operational safeguards

Rate limit login, password reset, contact, uploads and expensive endpoints according to actual threat; check enumeration, resource exhaustion, replay, idempotency, privilege abuse, brute force, CAPTCHA/verification tradeoffs and safe logging. Business fraud/payments go to FP-15.

## 8. Validation of remediations

Use controlled local/staging negative tests, dependency/static scans with versions, targeted unit/integration tests, safe fuzzing when authorized and threat-specific proof. Do not claim penetration testing without a real test. Assign severity by plausible exploit prerequisites, impact and confirmed reachability rather than scanner label alone. Do not weaponize vulnerabilities or send live exploit traffic beyond scope.

## Blockers and outputs

Default release blockers: exposed production secrets not resolved, broken tenant isolation, bypassable admin/data authorization, dangerous server-side injection, unauthenticated destructive operations, untested sensitive migrations and uncontained P0/P1 findings. Output threat map, control checklist, evidence-linked findings, patches owned by respective code modules, test results, residual risks and required human/security review. **No official security certification.**
