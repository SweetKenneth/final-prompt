# FP-06 — Technical SEO, Indexability and Machine Readability

**Trigger:** public indexable website. **Skip:** private apps, APIs with no public pages, non-web software, or projects where SEO is irrelevant. **Owner:** SEO policy, metadata, canonical rules, sitemap/robots/schema.

## Goals and operating rules

Make legitimate public content discoverable, accurately described, shareable and technically sound. Preserve design, brand and core messaging. No invented content, business credentials, reviews, ratings, schema, Search Console results, rankings, Google endorsements or guaranteed indexation. Coordinate brand assets with FP-08 and publisher/legal identity with FP-07.

### 1. Metadata and snippets

Inventory canonical indexable routes; create distinct, truthful, useful title and meta-description content matched to page intent. Use ~45–60 title characters and ~135–160 description characters as **editorial heuristics**, not hard Google limits. Google may rewrite titles/snippets and truncate by display width. Fix duplicate templates where harmful, titles mismatching H1, unnecessary site name repetition and conflicting robots directives. Include noindex decisions only where appropriate.

### 2. Open Graph and social previews

Verify canonical `og:url`, title, description, type, image, site name, X/Twitter card tags and absolute accessible image URLs. Use representative images from FP-08, avoiding false client/partner marks. Browser/preview validation must be observed or marked unverified. Fit text in common crops without assuming all social platforms render identically.

### 3. Accurate structured data

Add/repair supported and applicable JSON-LD: WebSite, Organization/Person, WebPage, BreadcrumbList, Article, FAQPage, CollectionPage, DefinedTerm/DefinedTermSet, Product/Offer only where factual page content supports them. Validate JSON syntax, types and required properties, then check relevant Google rich-result eligibility where tooling is available. Schema.org vocabulary alone does not confer Google rich-result support. No fabricated authors, prices, reviews, ratings, products, or relationships.

### 4. Crawlability and indexing

Check actual HTTP status, canonical redirects, navigation reachability, URL parameter duplicates, noindex/canonical conflicts, SPA rendering, trailing slash, pagination and redirects. Generate/update `sitemap.xml` or a sitemap index for all canonical public indexable URLs, accurate optional `lastmod`; ensure `robots.txt` points to it. Exclude nonpublic/noindex/duplicate/test routes. `robots.txt` manages crawling—it is **not** an access control mechanism; use authorization and `noindex` appropriately, and avoid blocking crawler access to a page whose noindex needs to be read.

### 5. Internal links and information architecture

Reach major pages through ordinary HTML links; use descriptive anchors; connect topic clusters and breadcrumbs where real hierarchy exists; avoid orphan pages, invented taxonomy and unnatural overlinking. Treat 2–3 clicks as a useful heuristic, not a universal ranking rule.

### 6. Headings and page semantics

Prefer one clear primary H1 and logical nested H2/H3 structure; fix confusing headings used solely for styling, inaccessible landmark structure, and duplicate primary headings that harm comprehension. Multiple H1s are not automatically an SEO error; prioritize human clarity and semantics over arbitrary counts.

### 7. Image/media SEO

Use meaningful alt text for informational images, empty alt for decoration; size assets appropriately, use modern formats, declare dimensions and prevent CLS, optimize hero/LCP resources, and lazy-load below-fold media where appropriate.

### 8. Core Web Vitals

Coordinate FP-13 and FP-04 on measured LCP, CLS, INP, mobile performance, third-party scripts, fonts and critical assets. Never state measurements that weren't collected.

### 9. Content quality and factual support

Fix misleading or thin boilerplate, stale factual statements, unsupported claims, keyword stuffing, broken references and confusing above-the-fold purpose, but seek approval before major editorial rewrites. Add editorial bylines, sources and last-updated timestamps only when factual and meaningful.

### 10. Trust and identity

Use accurate About, contact/publisher references, independent/unaffiliated disclosures as appropriate. Do not manufacture professional qualifications, editorial independence or legal statements. Treat E-E-A-T as a quality framework, not a separate numeric algorithm or guaranteed ranking lever.

### 11. Brand/local/entity consistency

Ensure canonical site name, verified contact/social profiles, logo attribution, domain, favicon, manifest and schema agree. Add local business markup only for actual eligible local businesses with true details; no made-up physical address or geographic targeting.

### 12. Accessibility and machine-readable extensions

Check link/button names, semantic landmarks and usable navigation. Optionally produce `/llms.txt` describing actual content and URLs, with site/publisher authorization; do not claim Google uses it as a ranking signal or that bots must obey its instructions. `robots.txt`, `sitemap.xml` and site policy remain separate mechanisms.

## Deliverables and tests

Page inventory with canonical URL, title, description, index/noindex, OG, schema; sitemap/robots report; changed files; validator results; broken links and redirects; runtime build; unverified external preview/Search Console claims. Do not delete valuable public pages or alter crawl policy without owner review where impactful.
