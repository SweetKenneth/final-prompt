# FP-13 — Performance, Capacity, Scalability and Cost Efficiency

**Trigger:** software with measurable runtime cost, latency, resource pressure or user-facing performance. **Rule:** optimize measured bottlenecks, not speculative microbenchmarks.

## Baseline

Identify success metrics and environment: web LCP/CLS/INP and device/network cohort, API p50/p95 latency, throughput/error rates, cold start, memory/CPU, queue lag, DB load, storage/bandwidth and third-party per-call costs when accessible. Record representative fixtures and measurement limitations. Avoid quoting numbers without executed tools.

## Frontend and rendering

Inspect critical request chain, rendering/hydration and expensive effects, large bundles/vendor scripts, fonts, image/video assets, DOM complexity, layout shifts, interaction responsiveness, state updates and cache policy. Use code splitting, compression, careful image priorities, smarter data fetching and simplified render work when benefits are credible. Preserve UX/SEO/accessibility.

## Backend and data

Profile repeated API calls, N+1 queries, serial awaits, oversized payloads, missing pagination, blocking CPU work, DB indexes/plans where available, connection limits, cache invalidation, serialization, external timeouts and concurrency caps. Favor bounded work and correct results over unbounded parallelization. Do not cache sensitive/tenant data across users.

## Capacity and fault behavior

Set reasonable resource limits based on actual requirements; test burst/steady workloads only in authorized staging/local environments. Check backpressure, queue growth, rate limits, memory leaks and graceful degradation. Never load-test unauthorized production/third-party services. Distinguish low traffic from proven scale-readiness.

## Unit economics

Map hosting/storage/egress, CDN, LLM/token usage, paid APIs, jobs and retries, logs and background tasks. Identify cost-per-operation or per-customer only if billing/usage data exists; use explicit assumptions otherwise. Add safe budgets, caps, deduplication and rate limits where relevant. Avoid recommending upgrades or new services with unverified cost/benefit.

## Verification

Run comparable before/after measurements with environment, fixtures and sample count. Report regressions, throughput improvements, p95 where available, task cost estimates, changed files and trade-offs. If metrics unavailable, state 'optimized by inspection; performance impact unmeasured'.
