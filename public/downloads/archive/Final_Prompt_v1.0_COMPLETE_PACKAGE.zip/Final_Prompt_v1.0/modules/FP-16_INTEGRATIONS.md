# FP-16 — Third-party APIs, Email, Webhooks, Jobs and Communications

**Trigger:** external services, SMTP/email, notifications, social API, webhooks, queues, cron jobs, file ingestion or import/export exist.

## Integration inventory

List provider, owner, environment, authentication mode, endpoints, rate limits, data classes, contract/version, inbound/outbound direction, failure handling, business criticality, retries and cost where known. Inspect actual code and provider docs rather than assuming credentials/features. Identify risky implicit dependencies and vendor lock-in only when relevant.

## Input/output correctness

Validate request construction, response schemas, pagination and cursor handling, timezones, encoding, webhook signatures, replay windows, redirect handling, file format/size bounds and idempotency keys. Handle 429, 500, timeouts, missing fields, schema drift, partial batches and duplicate/out-of-order events. Prevent infinite retries, duplicate notifications and silent record loss. Ensure dead-letter or replay capacity only when queues actually exist.

## Email, contacts and leads

Check opt-in/consent and unsubscribe requirements based on actual use and jurisdiction; validate input, email templates, sender domain/setup if authorized, bounce/complaint handling, suppression lists, abuse/rate limits and privacy-safe content. Differentiate transactional vs marketing mail. Never send test mail to real users or assume deliverability solely from application success.

## Jobs and automation

Inspect cron cadence/timezones, concurrency, retries, idempotency, schedules, worker restart, checkpointing, last successful run, side-effect recording and cost caps. Prevent dual workers executing the same money/data operation unless safely designed.

## Safe testing

Prefer fake endpoints/sandboxes/contract fixtures and signed sample events. Where provider network access is unavailable, report `UNVERIFIED_UPSTREAM`. Avoid leaking credentials in request logs. Do not alter customer-facing provider configurations without approval.

**Output:** provider matrix, contract failures, fixed files, exact tests, event replay proof where relevant, service outage plans and external validations remaining.
