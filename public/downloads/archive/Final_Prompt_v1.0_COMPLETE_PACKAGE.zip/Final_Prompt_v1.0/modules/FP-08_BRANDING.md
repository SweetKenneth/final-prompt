# FP-08 — Brand Identity, Replacement and Asset Perfection

**Default mode:** `AUDIT_ONLY` (preserve existing brand). **Full implementation mode:** `APPROVED_REBRAND`, requiring explicit instruction to replace the existing identity. **Trigger:** site/app with visible brand, icons, templates or marketing assets.

## Mode A — Brand Audit & Repair (default)

Inventory canonical name, domain, logo, colors, typography, voice, favicon, manifests, loading/error states, public graphics, template references, alt text, structured data identity, OG/X previews, contact emails and product screenshots. Find mismatched identities, blurry icons, broken assets, conflicting names and unauthorized vendor/template remnants. Make only low-risk corrections to existing authorized assets; propose a full identity change, but never execute it without permission.

## Mode B — Approved Full Brand Replacement

1. **Vendor/template residue:** search full repository, built output, static assets, manifest, `head`, metadata, favicons, OG previews, comments, CSS, loading screens, imports, docs and assets for known template brand strings (for Lovable-built projects: `Lovable`, `lovable`, `Made with Lovable`, `lovable.dev`, supplied default icons). Replace stale or unauthorized source identity without stripping platform/OSS attribution required by contract/license, removing functional dependencies, or suppressing legitimate provider references.
2. **Brand discovery:** infer proposed name from confirmed content/domain/owner direction; identify category, users, message, tone and existing design strengths. If identity conflicts among source files and instructions, surface alternatives rather than guessing commercial ownership.
3. **Concept exploration:** design at least three distinct, purposeful logo/identity directions. Evaluate legibility at 16px, uniqueness, typography, category fit, small-size recognition, accessibility, mobile/dark/light variants and professional trust. Record selection rationale and any required owner approval. Do not claim trademark availability without a proper search.
4. **Logo family:** produce primary logo, horizontal wordmark where appropriate, mark-only, mono, reversed light/dark, square app icon and favicon-safe shapes. Use correct vector/raster format, safe padding and crisp small sizes; avoid tiny textual details.
5. **Favicon/PWA assets:** when relevant, create and wire `favicon.ico`, `favicon.svg`, 16x16, 32x32, optional 48x48, 180x180 Apple touch icon, 192/512 PWA icon, maskable variant, Safari pin where supported, related manifest/browser metadata as applicable. Prefer actual framework/browser support to mandatory generated clutter.
6. **Social graphics:** produce branded 1200x630 OG default, compatible X card, key page images and optional square fallback. Use safe margins, clear text, real brand/name and no invented social proof. Where image tooling is absent, describe proposed graphics and mark generation pending instead of claiming creation.
7. **Metadata/manifests:** reconcile app name, browser title, short_name, theme/background color, icons, Apple app title, organization schema logo, page metadata, favicon links, OG/X images and installed PWA identity.
8. **UI application:** update header, footer, mobile navigation, loading/error/404/empty screens, modals, forms, CTAs and any approved email templates. Maintain contrast and aspect ratios; do not disrupt working product flows.
9. **File hygiene:** delete obsolete branding assets only if no runtime reference or third-party obligation remains; use descriptive paths (`logo-primary.svg`, `logo-mark.svg`, `og-default.png`, `og-[slug].png`). Update imports and regenerate build references safely.
10. **Verification:** compile/build, validate asset URLs, inspect representative mobile/desktop dark/light renderings if visual tool exists, check PWA install names/icons and previews in real environments when possible, search source and built assets for unintended vendor identity. Mark unverified external previews explicitly.

## Acceptance / outputs

Report vendor/template references changed or intentionally retained and why, identity exploration, direction selected, artwork/asset inventory, visual consistency, modified files, exact verification results and human approval needs. Do not claim a logo was 'generated' if you only wrote instructions. The brand module and FP-06 share metadata via a designated integration writer; FP-07 controls ownership/attribution copy.
