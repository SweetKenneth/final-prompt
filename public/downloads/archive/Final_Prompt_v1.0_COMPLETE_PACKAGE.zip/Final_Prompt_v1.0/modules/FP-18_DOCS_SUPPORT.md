# FP-18 — Documentation, Developer Handoff and Customer Operations

**Trigger:** all software; adapt to its audience and maturity.

## Truthful documentation

Synchronize README, setup instructions, configuration examples, API contracts, developer scripts, architecture decisions and deployment runbooks with actual repository and runtime. Document required environment variables **by name only** with safe examples, never secret values. Remove stale claims and obsolete setup steps only after verification.

## Operator and customer workflows

Describe installation/onboarding, account access, common failures, privacy/data request/contact paths, maintenance, dependency upgrades, release/rollback, incident ownership, monitoring and troubleshooting in plain language. For developer products, provide API examples, common errors, versioning/deprecations, permissions and cost/rate-limit boundaries. For non-web apps, cover distribution/uninstall/update paths where applicable.

## Product truth and accessibility

Review false feature descriptions, dead screenshots, confusing instructions, inconsistent help text, support/error recovery routes, missing accessibility instructions and unsupported company/partner claims. Do not invent support SLAs, paid tiers, customer counts or staffing. Distinguish documentation proposals from features implemented.

## Deliverable

Actual docs updated, cross-links, screenshots only if captured, runbooks, manual steps, existing gaps and version/owner attribution confirmed. Verify command examples where safe. Documentation alone never closes a runtime defect.
