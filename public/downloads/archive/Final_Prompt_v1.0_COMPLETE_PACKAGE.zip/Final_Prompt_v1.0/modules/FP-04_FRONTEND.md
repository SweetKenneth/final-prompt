# FP-04 — Frontend Production Audit and Remediation

**Trigger:** rendered website, app UI, forms or client-side state. **Default:** preserve product intent, route structure, current visual brand, content meaning and core user journeys.

## 1. Functional correctness

Inspect public/private pages, routes, layouts, hooks, client utilities, state, forms, accessibility behavior, animation, assets, metadata and integrations. Test links, buttons, CTAs, tabs, dropdowns, menus, accordions, search/filter, modals, navigations, async states and redirects. Handle null/undefined, empty results, malformed links, bad images, long text, repeated clicks, slow/failed network, viewport changes and partial hydration. Fix actual broken functionality with small patches; never silently remove a feature.

## 2. Forms and user input

Align client validation with authoritative backend contracts. Check required fields, emails/URLs, length/enum constraints, checkboxes/radios, duplicate submission, pending/success/error messaging, error focus, accessible descriptions, bot/abuse mechanisms when used, and clear recovery. Do not leak sensitive field values into logs or analytics.

## 3. Data flow and state

Trace fetches/server action results into rendering and state transitions. Fix stale closures, bad effect dependencies, race conditions, uncontrolled/controlled warnings, overlapping requests, canceled navigation, cache invalidation, mismatched DTO assumptions, hydration mismatches and redundant state. Respect existing frameworks; avoid adding state-management libraries without need.

## 4. Performance and Core Web Vitals

Evaluate actual bottlenecks and relevant user devices: unnecessary renders, heavy derived work, bundles, dependencies, asset weight, image dimensions and formats, video/media, font loading, loading strategy, layout shifts and interaction latency. Measure LCP, CLS and INP where a browser/performance harness exists. Do not claim lab scores when browser instrumentation was unavailable. Use lazy loading for noncritical media, not for likely LCP images; prioritize fixes by effect on users.

## 5. Reliability and edge states

Handle optional/async data, failed requests, timeouts, 404/403/offline, loading/empty/error states, optimistic rollbacks and recoverable interruptions. Clean timers, listeners, observers and subscriptions on teardown. Remove debug UI, leaking console logs, broken placeholders and unstable test hooks only after verifying intent.

## 6. Client-side security/privacy

Check rendered HTML, URL parsing, navigation origins, token storage, secrets exposed by bundlers, analytics PII, errors/logs and third-party scripts. Ensure external link handling is safe for the browser support matrix; `noopener` is appropriate for new-window links and `noreferrer` is optional based on referral policy. Never treat client validation or hidden UI as authorization.

## 7. Accessibility

Inspect semantics, landmarks, accessible names, labels, errors, keyboard interactions, focus visibility/management, dialogs, menus, tabs, image alternative text, decorative media, color contrast, readable text, touch targets, reduced motion and responsive zoom. Use WCAG 2.2 AA as a target where applicable; manual assistive-tech tests remain necessary for meaningful coverage. Don't add ARIA that contradicts semantic HTML.

## 8. Responsive/visual robustness

Test mobile, tablet, desktop, ultrawide and zoom; address overflow, clipping, sticky headers, z-index, grids, viewport-height bugs, landscape/safe-area, dynamic long names/URLs, localization lengths and font loading. Preserve visual identity. Use real browser screenshots/testing if tools exist; otherwise state unverified visual aspects.

## 9. SEO/indexing/metadata coordination

Review route headings, canonical rendering, crawlable links, social metadata, image alternatives and search accessibility. FP-06 is the sole owner of SEO policy, sitemap/robots/schema decisions; coordinate changes rather than duplicate. Do not apply universal title or description hard caps as if Google required them.

## 10. Structured data/machine readability

Apply validated schema/manifest/semantic output only where FP-06 specifies and the page genuinely supports it. `llms.txt` may be added as an optional descriptive convention, never as guaranteed search ranking or AI visibility mechanism. Do not create misleading schema or untrue provenance claims.

## 11. Content quality and trust

Identify placeholder text, duplicate copy, confusing CTAs, unsupported marketing/legal/medical/regulatory/financial claims, stale dates and broken sources. Propose material content changes for approval; make small correctness improvements without changing product thesis. Coordinate publisher identity with FP-07 and FP-08.

## 12. Code quality

Remove clearly unused files/imports/effects/state and repeated code; improve type safety, naming and organization. Avoid introducing frameworks or abstractions solely for aesthetic reasons. Preserve lint/style conventions and user-visible behavior.

## 13. Test and build

Run framework-appropriate lint, typecheck, unit/component/E2E tests and production build where available. Verify major routes, forms, mobile navigation, error screens, metadata and asset paths. Do not claim OG previews or cross-browser behavior without external/browser confirmation. Log commands, results, files changed, known limitations and regressions.

## Deliverable

Prioritized defects fixed; UX, performance, accessibility, SEO/schema, reliability/security, maintainability; changed files; executed tests; and unresolved/manual verification. Keep frontend and backend contract versions synchronized.
