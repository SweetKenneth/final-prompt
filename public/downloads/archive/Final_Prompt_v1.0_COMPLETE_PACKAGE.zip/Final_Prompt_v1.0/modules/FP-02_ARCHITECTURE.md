# FP-02 — Architecture, Contracts and Maintainability

**Trigger:** any multi-module codebase or app whose failures suggest structural weaknesses. **Role:** assessment and targeted cross-cutting improvements; don't rewrite the architecture to match a preferred framework.

Inspect actual runtime boundaries, folder/module graph, dependency direction, state ownership, domain models, public API compatibility, synchronous/asynchronous paths, startup/shutdown lifecycle, error propagation, resource lifetimes, versioning, platform-specific constraints, feature flags and configuration precedence. Document actual diagrams and trace at least the key user journeys from input through persistent side effects to result.

Find and safely repair confirmed: cycles creating initialization issues; duplicated domain logic with divergent behavior; inconsistent data contracts; problematic abstraction leakage; unsafe dependency injection/initialization; weak boundaries between privileged/unprivileged modules; unbounded fanout; incompatible API versions; brittle imports; hidden global state; confusing configuration; retired feature code still reachable. Respect platform restrictions (serverless runtime, browser-only APIs, native mobile capabilities, offline execution) and existing conventions.

When architecture changes are high-risk, propose an incremental migration with interface contracts, compatibility adapters, feature flags, tests, rollback and concrete measurable benefits; do not silently restructure the app. Track ADRs for significant decisions. Coordinate affected modules and appoint one writer per shared artifact.

Verification: baseline tests; architectural contract checks; smoke tests for primary journeys; dependency/compilation checks; evidence of no public interface regression. Report what was repaired, proposed only, or unverified, plus files changed and reason.
