# FP-17 — AI, LLM, Retrieval and Autonomous-Agent Production Assurance

**Trigger:** the product actually uses LLMs, agent loops, RAG/search embeddings, model tools, AI evaluation, automations, or agent-generated code. Otherwise NOT_APPLICABLE.

## System inventory

Map model providers/versions, routing/fallbacks, prompts/system messages, tool registries, retrieval pipelines, embeddings/stores, user context, cost/rate limits, confidence behaviors, approval policies, memory, persistence, action audit trails and external data boundaries. Distinguish simulated, shadow, staged and real execution. Do not describe a model/tool as available if only an interface stub exists.

## Prompt injection and trust separation

Treat retrieved documents, websites, user uploads, tool output, emails, repository comments and external model text as **untrusted data**. Prevent those surfaces from overriding system instructions, tool authorization, secret handling and permission policy. Limit what crosses model boundaries; sanitize/redact confidential content and use structured arguments validated server-side. Audit retrieval citation grounding and unsupported inference where product-critical.

## Tool and agent permissions

Verify allowlisted tools, least privilege, explicit approval for external side effects, per-user/tenant boundaries, time-limited activation where present, replay protection, token/credential handling, command sandboxing, network access, filesystem boundaries, human override and kill switch. An LLM may propose an action; server-side checks authorize it. Avoid shell/production execution from untrusted prompts.

## Robustness and correctness

Test ambiguous natural language, format/schema violations, hallucinated provider facts, multi-turn state, context window rollover, retries, duplicate skills/actions, contradictory user instructions and streaming/cancel paths. Distinguish deterministic capability execution from model-generated planning. Ensure state is securely checkpointed and scoped to the right user/project.

## Model selection and economics

Measure quality, failure rate, latency, token/cost budgets, caching, routing, truncation, external quota and rate limits. Use cheap models only when they satisfy measured correctness and safety needs. Avoid silently switching models when quality is critical; define explicit fallbacks and degraded behavior.

## Evaluations and release evidence

Build representative golden tasks and adversarial/negative fixtures (non-destructive); include prompt injection tests, cross-user tool attempts, format/schema reliability and regression before/after. Track dataset provenance and avoid contaminating evals with answers. Do not call a capability 'production proven' because mock tests passed. If skills or tool access have activation/expiry rules, verify authorization and revocation behavior.

**Output:** model/tool inventory, trust-boundary diagram, authorization weaknesses, evaluation matrix, repaired contracts and limits, unresolved risk/cost and observed vs unobserved execution.
