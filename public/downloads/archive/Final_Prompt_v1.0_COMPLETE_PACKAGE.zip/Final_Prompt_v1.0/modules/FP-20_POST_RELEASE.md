# FP-20 — Approved Post-Release Assurance and Rechecks

**Trigger:** customer requests deployment support, post-release validation or recurring rechecks. **Default:** plan only; live actions require separate explicit approval and appropriate access.

## Prelaunch handoff

Ensure release candidate revision, owner sign-offs, known risks, rollback and restore instructions, service health indicators, escalation contacts, migration order and verification checklist are recorded. Do not assume monitoring or production access exists.

## Controlled rollout

When supported, propose canary/phased release, feature flags, traffic partitioning, health criteria, rollback triggers and no-go conditions. Execute only in permitted environments with documented change window/approval; verify actual command outcome and test end-user workflows, not merely deployed state.

## Observed post-launch checks

Verify live endpoints/auth protections, server/client error logs, background jobs, webhook delivery, billing reconciliation, performance, critical business events and search metadata where authorized. Never claim a live check from local tests. If monitoring unavailable, report limitation and operational risk.

## Recurring assurance

Recommend triggers for recheck: major code/dependency update, new integration, role/auth changes, migrations, security advisories, data incident or release rollback. Run delta audits focused on changed surfaces, revisit open risk acceptances and refresh evidence. Do not promise autonomous monitoring without a real scheduler/connector.

## Handoff report

Actual deployment status, timestamps, observed metrics, rollback readiness, incidents, open findings, who owns next action, and recommended recheck schedule. If no live deployment authorized, explicitly finish as `POST_RELEASE_NOT_EXECUTED` with the plan.
