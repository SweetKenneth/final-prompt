# FP-14 — Tests, UX Verification, Accessibility and Compatibility

**Trigger:** all applications; select checks by product surface. **Rule:** do not assert a test ran because test code exists.

## Test pyramid and coverage

Inventory current unit, integration, contract, component, E2E, mobile/native, API, smoke, security and accessibility tests; identify critical user journeys and risky gaps. Prioritize meaningful behavior over inflated test counts. Maintain deterministic fixtures, isolation, cleanup and representative negative tests. Avoid mocks that bypass core business behavior in purported integration tests. Keep test changes proportionate to the risk.

## Regression matrix

For each major flow, cover happy path, missing/invalid inputs, unauthorized user, cross-user attempt when applicable, network failure, timeout, duplicate/retry, empty data, concurrent action, rollback and UI error messaging. Include version compatibility where public clients depend on contracts. Test failures introduced by patches immediately, then re-run full applicable suite at release gate.

## Accessibility

For web apps target WCAG 2.2 AA where appropriate: semantic headings/landmarks, labels/errors, keyboard and screen-reader flow, focus order/visibility, accessible dialogs/menus, alternative text, contrast, non-color-only cues, reduced motion, target size, text resizing/zoom and accessible authentication where relevant. Automated checks catch a subset; manually test keyboard navigation and selected assistive-tech flows if tools/devices available. Document remaining manual needs honestly.

## Visual and device compatibility

Check current supported browser/device matrix; small mobile, tablet, desktop/wide, portrait/landscape, zoom, slow network, PWA/offline if applicable, high density and dark mode where supported. Use actual browser screenshots/interaction tools or mark visual tests unverified. Do not invent an unsupported platform requirement.

## Build and dependency commands

Run declared install, lint, typecheck, tests and production build if authorized and environment supports them. Avoid destructive package manager actions without review. Record exact command, exit code, stdout summary, failed assertions, revision, environment and timestamp. Treat skipped, not-run and flaky tests as separate states; do not 'fix' a failing test by weakening important expectations.

## Outcome

Produce test matrix by critical workflow, coverage gaps, automated and manual results, inaccessible verification surfaces and ownership of each failure. Only FP-19 declares final release readiness based on this evidence.
