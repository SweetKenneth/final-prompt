# FP-05 — Targeted Component Perfection Pass

**Trigger:** user-selected or defect-linked component. **Scope:** component, direct child components, props/hooks/state/effects/handlers, styling, assets, relevant surrounding integration. **Boundary:** do not touch unrelated product areas.

## Execution instruction

Audit the chosen component end-to-end, reproduce actual defects, implement safe targeted fixes, and verify its public API and intended design remain compatible. Never rewrite from scratch unless the component is fundamentally unsalvageable and a redesign is separately approved.

1. **Functional correctness:** test click handlers, form submit, menus/tabs/accordions, filters, navigation, search, state conditions, missing/invalid props, empty/null data, long content, broken images, repeated clicks and slow/failed data.
2. **Runtime reliability:** prevent avoidable exceptions, unhandled async failures, invalid hook dependencies, stale state, hydration/key warnings, controlled/uncontrolled input warnings, missing timer/listener/observer/subscription cleanup, and async state updates after teardown.
3. **Performance:** profile expensive derived computations, child rerenders, heavy props, unnecessary function/object recreation, image/media loading and blocking render. Memoize, split or lazy-load only where a measurable/credible benefit outweighs complexity.
4. **Maintainability:** simplify tangled logic, deduplicate repeated JSX/handlers/constants, improve names, extract focused helpers, preserve established patterns; remove truly unused imports/state/effects/dependencies.
5. **Type safety:** tighten types, optional/required props, defaults, unions and runtime guards. Avoid `any` without justification. Keep prop and event semantics stable for callers.
6. **Accessibility:** semantic elements, keyboard controls, focus capture/return, accessible names, error description, appropriate ARIA, heading structure, alt/decorative images, contrast and touch targets.
7. **Responsive robustness:** mobile/tablet/desktop, zoom, long titles/descriptions/URLs, clipping, sticky/z-index, light/dark variants where supported, consistent spacing and typography.
8. **SEO when relevant:** preserve crawlable links, meaningful headings and descriptive anchors; do not inject duplicate H1s or hidden critical text.
9. **Security:** guard untrusted URLs/HTML, avoid exposed tokens/debug data, use safe new-window link semantics and avoid bypassing app authorization.
10. **Tests and proof:** add or update straightforward tests in existing framework; run relevant lint/typecheck/build; manually inspect diff and integration call sites. If no browser, state that visual/interaction tests were not observed.

## Loop and report

`reproduce -> patch -> focused test -> dependent route smoke -> inspect diff -> checkpoint` for each finding. Report defects fixed, performance/reliability/accessibility/maintainability changes, changed files, commands and results, remaining risk. Do not promise 'pixel perfect' without visual evidence. Trigger follow-up FP-05 if other modules materially change this component.
