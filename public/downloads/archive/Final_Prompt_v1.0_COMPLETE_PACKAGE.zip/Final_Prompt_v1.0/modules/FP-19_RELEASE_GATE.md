# FP-19 — Independent Verification, Evidence Audit and Release Decision

**Always required.** **Default:** no code changes in this module; identify regressions and send them to owner modules for an authorized fix loop.

## Separate 'done' from 'proven'

Re-read the latest baseline, findings, changed files, approvals, test log, data migrations, environment, release candidate revision and deployment constraints. The verifier must not simply trust the agent that authored the fixes: independently rerun at least the critical checks and inspect the exact code diff, test setup and negative-path assertions. When no independent agent exists, run an explicit separate verification pass with fresh evidence; disclose the limitation.

## Mandatory gate families (when applicable)

- `GATE-IDENTITY`: authentication, authorization, tenant isolation, privileges and secret leakage.
- `GATE-DATA`: ownership, constraints, migrations, backup/restore and data-loss risk.
- `GATE-FUNCTION`: primary workflows, API/client contracts, critical forms and negative cases.
- `GATE-BUILD`: reproducible production build, type/lint/test outcome, dependency integrity.
- `GATE-ACCESSIBILITY`: keyboard/focus/semantic checks and manual coverage disclosure.
- `GATE-PERFORMANCE`: measured regression against baseline for critical paths if measurement is available.
- `GATE-OPERATIONS`: monitoring, error behavior, incident/rollback plan, production parity.
- `GATE-PAYMENTS`: money/entitlements/reconciliation when relevant.
- `GATE-PUBLIC`: relevant SEO, branding, legal publication review and correct metadata.
- `GATE-AI`: model/tool authorization, prompt injection boundaries, quality evals when relevant.
- `GATE-APPROVAL`: all high-risk writes and published legal/brand changes approved by correct owner.

## Gate statuses

`PASS` (with test evidence); `FAIL` (reproducible contradiction); `NOT_APPLICABLE` (documented absence); `UNVERIFIED` (not tested or inaccessible); `BLOCKED` (cannot proceed until remediation/approval); `DEFERRED_APPROVED` (authorized, documented risk acceptance, only when not a mandatory blocker).

## Blind-spot challenge

Run FP-01's read-only final blind-spot pass; search changed files for side effects, regression tests weakened to pass, ignored errors, new dependency/security exposure, confidential data added to commits, unexpected breaking changes, inaccessible environments and newly introduced vulnerabilities. Open fresh findings for new risk.

## Release verdict

- **SHIP:** all mandatory applicable gates PASS or justified NOT_APPLICABLE; no unresolved P0/P1; necessary live/production-specific uncertainties disclosed and not release-blocking under agreed policy; requisite owner approvals on record. This is not a guarantee.
- **BLOCK:** unresolved P0/P1, exposed secrets, broken access isolation, payment/data integrity failures, critical untested migration, broken production build, missing mandatory rollback, or mandatory gate FAIL/UNVERIFIED where credible severe consequence exists.
- **HUMAN_REVIEW_REQUIRED:** no automatic blocker proved but unresolved legal/privacy, branding, risk acceptance, missing real-provider verification, or scoped production questions require accountable owner sign-off before release.

Never compute 'SHIP' from the average of unrelated numeric scores. Do not sign a report on the owner's behalf or falsely claim auditor independence. For optional P2/P3 acceptance, name approver, scope, expiry and monitoring/mitigation in the risk ledger.

## Final report structure

1. Project/revision/environment/scope and untested boundaries.
2. Starting vs remaining P0–P3 counts, findings closed with evidence IDs.
3. Module applicability matrix and why skipped.
4. Changed files and user-visible effects.
5. Exact tests/commands, exits, artifact links and manual browser checks.
6. Mandatory gate table with status, evidence, reviewer/limitations.
7. Legal/privacy or stakeholder review checklist and unapproved actions.
8. Rollback/recovery summary and deployment prerequisites.
9. Residual risks/owner acceptance and ongoing monitoring.
10. **One verdict:** SHIP, BLOCK, HUMAN_REVIEW_REQUIRED, with precise reasons.

Title the artifact **Final Prompt Readiness Report**. Do not call it an official 'security certification' or claim OWASP/NIST/W3C endorsement.
