# FP-01 — Universal Software Gap Analysis and Remediation Roadmap

**Mode:** STRICTLY READ-ONLY. **Required:** discovery and final blind-spot sweep. **Audience:** any stack, including websites, APIs, CLI, mobile, desktop, embedded, AI/agent platforms.

## Directive

Perform a comprehensive, stack-agnostic, multi-turn software gap analysis. Detect real gaps in the observed project; assign severity, risk, likelihood, impact and effort; produce a prioritized remediation plan; then challenge the inventory for hidden assumptions. This module must not change application code, settings or infrastructure. The master controller independently authorizes repairs via the appropriate owner module.

## Five ordered passes

### 1. Surface mapping
Inventory architecture, module structure, runtimes, product workflows, data/control flows, code ownership, auth and trust boundaries, external dependencies, deployment topology, business/economic model when present, users, stakeholders, and observability. Note every missing source of evidence. Use diagrams where they clarify actual boundaries; do not invent inaccessible systems.

### 2. Universal 20-category audit
For **each** category record `APPLICABLE`, `NOT_APPLICABLE`, or `UNKNOWN`, followed by evidence and specific findings:

1. **Architectural:** coupling, inappropriate layering, cyclic deps, single points of failure, missing control boundaries.
2. **Structural:** repository organization, unused code, inconsistent contracts, ownership ambiguity.
3. **Operational:** runbooks, environments, incident response, ownership, support, deployment readiness.
4. **Observability:** traces, logs, metrics, alerts, errors, monitoring blind spots.
5. **Governance:** approvals, auditability, access lifecycle, policy/version controls.
6. **Data integrity:** constraints, corruption scenarios, transaction/consistency guarantees, retention.
7. **Security:** authorization, identity, secrets, input handling, supply-chain and abuse surface.
8. **Scaling:** bottlenecks, concurrency limits, load assumptions, capacity.
9. **Economic/cost:** hosting/API/bandwidth/storage expenses, runaway loops, per-request economics.
10. **Productization:** onboarding, pricing gates, support, entitlement drift, supportability.
11. **Documentation:** architecture, API contracts, installation, troubleshooting, ADRs.
12. **Evolution/versioning:** backward compatibility, schema changes, migrations, deprecations.
13. **Human interaction:** UX, accessibility, error communication, dangerous actions.
14. **Testing/validation:** automated coverage, production parity, false mocks, test quality.
15. **Compliance/legal:** privacy disclosures, accurate claims, third-party license obligations, regulated-use requirements (only where actually applicable).
16. **Deployment/environment:** config, build parity, runtime restrictions, release/rollback.
17. **Dependencies:** maintainers, unsupported components, third-party outage and licensing risk.
18. **Performance:** latency, throughput, CPU/memory, layout/render performance.
19. **Redundancy/backup:** backup scope, recovery ability, restore evidence, disaster recovery.
20. **Narrative/cognitive clarity:** understandable product purpose, ambiguous instructions, operator cognitive load, user messaging.

For each actual finding include location, reproduction or bounded observation, affected users/systems, impact, likelihood, severity P0–P3, confidence level, ownership, and whether remediation is safe to automate.

### 3. Severity and risk scoring
Assign `severity(P0-P3)`, `risk(1-10)`, `impact(1-10)`, `likelihood(LOW/MEDIUM/HIGH)`, `urgency(CRITICAL/HIGH/MEDIUM/LOW)`, `effort(S/M/L)`, and `evidence_strength(OBSERVED/INFERRED/UNKNOWN)`. Rank severe known exploit/data-loss scenarios above superficial work. Do not convert absent test results into assertions of safety. Distinguish exposure from hypothetical possibilities.

### 4. Remediation roadmap
Order by dependencies and user impact:
- **Immediate:** data safety, secrets/permissions, availability blockers, billing integrity.
- **Short-term:** reproducible correctness fixes, regressions, operational visibility.
- **Mid-term:** structural work necessary for stability and maintainability.
- **Long-term:** nonblocking evolutionary optimization and optional enhancements.

Each row must state `owner_module`, affected files/services, acceptance test, fallback/rollback, estimated cost/effort, approval requirement, and recommended sequence. Avoid proposing speculative infrastructure without evidence it solves a problem.

### 5. Blind-spot sweep
Search explicitly for undocumented state, hidden side effects, external integrations, assumptions held only in a person's head, permission/ownership confusion, stale docs, disabled tests, synthetic test data diverging from production, secret config dependencies, platform restrictions, unknown customer contracts, and opaque runtime paths. Propose safe probes to resolve each. Mark unresolved unknowns without manufacturing answers.

## Outputs and validation

Produce `surface-map.md`, category coverage matrix (20 rows), risk-ranked `findings`, `remediation-roadmap.md`, `blind-spots.md`, and non-applicability reasons. On final rerun compare each finding's original evidence to a post-fix test at the same scope; never close a finding by inference. Validation requires every category considered, all real findings prioritized, and unknowns clearly isolated. **No code or config changes from FP-01.**
