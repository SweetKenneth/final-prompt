# FP-07 — Legal, Privacy, Attribution and Site Governance

**Trigger:** public site, customer-facing software, personal data processing, third-party content, licensed software or regulated claims. **Default:** `DRAFT_REVIEW`, not legal publication. **Important:** this module is not a substitute for a lawyer or privacy professional.

## Core truthfulness rules

Inspect actual processing, deployment, service providers, user flows, jurisdictional reach, licenses, marketing and publisher identity. Never assert that data is not sold, no tracking is used, data is deleted after N days, a company owns content, a product is compliant, or consent has been acquired unless supported by evidence/owner confirmation. If unavailable, add `REQUIRES_OWNER_INPUT` placeholders rather than polished falsehoods. Do not invent jurisdiction, governing law, age eligibility, tax identifiers, legal entity, PO box, employee numbers or accreditation. Publishing legal policies requires explicit human approval.

### 1. Legal inventory and privacy data map

Map visitors, customers, support users, cookies, account credentials, payments, logs, analytics, IP/device identifiers, health/financial/children's data if any, data sharing, processors, retention, deletion, transfers and third-party scripts. Identify which personal-data laws or platform rules **may** apply, without claiming a compliance conclusion. Flag consent/cookie mechanism issues and conflicts between actual behavior and current notice.

### 2. Privacy Policy draft at site-appropriate path

Draft plain-language, site-specific sections: operator/contact; categories collected and sources; purposes/uses; legal bases where applicable; service providers/sharing; data sales/sharing claims only if verified; cookies/tracking; retention criteria; user choices and rights as applicable; security limits; children/age suitability; cross-border handling if relevant; updates/effective date; contact mechanisms. If no analytics/cookies/accounts are used, do not claim otherwise; distinguish unavoidable server logs from optional analytics. Prefer specific facts to future-looking boilerplate.

### 3. Terms of Use draft

Draft fit-for-purpose: acceptance, operator, nature of service, user responsibilities, ownership of original protected material, third-party IP, allowed/restricted use with enforceable scope, accounts/payments where applicable, limitations/warranties subject to local law, takedown/reporting, external links, dispute mechanism/governing law if verified, changes, effective date and contact. Flag provisions needing counsel: arbitration, indemnity, age rules, automatic renewals, liability limits and geographic privacy obligations.

### 4. Independence, affiliation and regulated claims

For research, cultural archive, AI governance, medical/financial/legal, public policy or market commentary, place context-appropriate factual disclosures where needed. Do not imply endorsements by brands, regulators, standards bodies or publishers. Cite primary sources for important claims; avoid false 'fair use' guarantees or blanket liability waivers. Where third-party trademarks appear, distinguish editorial/nominative use from licensing and avoid unapproved logos.

### 5. Intellectual property and copyright

Attribute actual owners and creator(s) only when verified. Protect original copyrightable text, imagery and code within applicable law; do **not** claim automatic exclusive ownership of generic ideas, functional architectures, public facts or third-party materials. No blanket promise that Terms prevent scraping or that scraping is universally unlawful. Honor legally required OSS license and platform attribution. Add copyright year, notices, source policy and permissions/contact only when identity is established.

### 6. Optional `/llms.txt` descriptive file

If appropriate for a public research/editorial site and authorized, create `/llms.txt` as a descriptive inventory: site name, canonical domain, mission, audience, authoritative pages, major categories, definitions, verified publisher/creator attribution, verified profiles, contact, source/citation policy, accuracy/independence notice, content update date, sitemap/robots/privacy/terms URLs. Describe how to accurately summarize the site, but do not imply machine readers must follow these instructions or that search engines grant SEO benefit. Omit unsupported claims and unverified relationships.

**Special case: PromptFluid-owned projects.** When the owner confirms this identity applies, template attribution may read `A PromptFluid product by Kenneth E. Sweet Jr.` and ownership in relevant documents can be specified accordingly. Never hardcode that text for a third-party customer's project.

### 7. Footer/trust integration

Coordinate one footer writer with FP-04/FP-06/FP-08. Link to actual Home/About/Contact/Privacy/Terms, optional llms.txt and Sitemap where helpful; avoid broken links and clutter. If a visible no-affiliation or informational disclaimer is truly needed, draft a concise one tailored to the site's real content.

### 8. Site governance and machine readability

Coordinate `robots.txt`, `sitemap.xml`, canonical/JSON-LD and source attribution with FP-06. Evaluate governance documentation: editorial process, corrections, last updated, accuracy claims, responsible disclosure, abuse reporting, accessibility contact and data requests. Do not duplicate SEO-owned files in parallel.

### 9. Trust gaps and asset rights

Inventory About/contact clarity, third-party assets/fonts, licenses, user-uploaded content, consent for testimonials, publisher information, unsupported claim language, branded logos, media rights and accessibility expectations. Raise manual-review findings for ambiguous rights. Do not delete licensed attribution merely to satisfy a branding sweep.

### 10. Cross-project applicability

For libraries, internal tools, CLI/mobile/desktop apps, adapt this module to README license/NOTICE, app store disclosures, privacy dialogs and applicable third-party obligations. Do not manufacture web legal routes for non-web products.

## Verification and legal handoff

Test existence/HTTP of approved legal URLs and footer links, schema/publisher consistency, real cookie behavior vs notice, `llms.txt` contents, policy effective dates, actual processor inventory, accessibility and build. Submit a **Legal Review Required** checklist identifying unconfirmed facts and counsel questions. New privacy/terms text remains DRAFT until approval; do not self-certify 'legally compliant'. Report files changed, commands/results and unresolved jurisdictional/privacy issues.
