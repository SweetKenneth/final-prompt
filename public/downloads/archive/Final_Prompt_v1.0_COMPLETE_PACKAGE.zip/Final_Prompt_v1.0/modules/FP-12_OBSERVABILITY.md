# FP-12 — Reliability, Monitoring, Incident Response and Rollback

**Trigger:** nontrivial runtime, online service or critical local workflow. **Skip** cloud-specific sections where no cloud exists.

## Failure model

Enumerate process crash, dependency outage, database/storage error, timeout, slow requests, malformed payload, overload, network partitions, retries, scheduled task failures, queue redelivery, stale caches, failed feature flags, partial deployment and compromised credentials when relevant. Distinguish expected recoverable failures from data/financial integrity failures.

## Runtime resilience

Verify request timeouts, cancellation, backoff/jitter, circuit breaker when justified, concurrency bounds, graceful shutdown, worker termination, idempotency, queue/replay semantics, restart behavior, fail-closed security paths and degraded-mode UX. Never make a dangerous fallback that bypasses authorization or billing gates. Do not install unnecessary orchestration systems.

## Observability

Determine minimal measurable service-level indicators: core request success/latency, error rate, job failures, webhook retries, payment errors, queue lag, client runtime exceptions and data consistency. Add safe structured logs, correlation IDs, actionable alert thresholds and redaction. Avoid storing PII/secrets; define retention proportionate to requirements. Do not declare an SLO without owner input.

## Incident and operational playbook

Create concise runbooks: detect, triage, contain, notify authorized operator, recover, verify, document. Define responsible roles from actual personnel, not fictitious 24/7 team. Include credential compromise, outage, corruption and failed deployment escalation. Create feature disable/rollback and restore paths where feasible.

## Failure injection and proof

In local/staging/sandbox only with scope approval, simulate upstream 500s/timeouts, duplicate jobs, partial writes, resource exhaustion at safe bounds, reconnect/restart and lost network; confirm data integrity, visible errors and recovery. If production metrics/alerts are inaccessible, document unverified operations rather than invent dashboards.

**Output:** reliability findings, implemented safe guards, monitoring inventory, incident/rollback runbook, test evidence, remaining unknowns and ownership/alerting gaps.
