# FPL/1 — Final Prompt Language (Proposed DSL)

**Status:** design specification, **not implemented interpreter**. Use FPL to encode Final Prompt checks in a portable, versioned, auditable rule format instead of exposing full proprietary instructions as copyable public prompt files.

## Purpose and security boundary

FPL is a declarative rule language for **applicability, reads, findings, safe repair policy, acceptance tests, evidence, and release gates**. It is not a general-purpose programming language and should not contain arbitrary shell scripts or JavaScript executed without sandboxing. A trusted server-side interpreter performs all enforcement and may call a separate authorized coding agent. Obscure syntax is not a trade secret defense; server-side execution, access controls, product differentiation, rate limiting and audit trails are the actual controls. A client can still learn some rule behavior from responses.

## Rule object

```yaml
fpl_version: '1'
id: FP.SECURITY.AUTHZ.OBJECT_SCOPE
version: '1.0.0'
owner_module: FP-09
phase: P3
applies_when:
  all:
    - has_server_routes: true
    - has_user_or_tenant_scoped_resources: true
inspect:
  - route_handlers
  - authorization_middleware
  - resource_ownership_queries
findings:
  severity_if_proven: P1
  required_evidence:
    - route_or_operation
    - affected_resource
    - sanitized_negative_test
repair:
  allowed_actions:
    - isolated_source_patch
    - non_destructive_tests
  requires_approval:
    - database_destructive_migration
    - production_write
  preserve_public_contract: true
  shared_writer: FP-03
verification:
  - id: deny_anonymous
    method: authorized_integration_test
  - id: deny_cross_user
    method: authorized_integration_test
  - id: allow_owner
    method: authorized_integration_test
  - id: typecheck
    method: command_result
release:
  mandatory: true
  on_failed: BLOCK
  on_unverified: BLOCK
  on_not_applicable: JUSTIFY
budget:
  estimate_tokens: 12000
  max_attempts: 3
```

## Core schema vocabulary

| Key | Meaning |
|---|---|
| `id`, `version`, `owner_module` | immutable identity and one module owner |
| `phase` | orchestration phase; never bypass global priority |
| `applies_when` | predicates evaluated from evidence/manifest, not hallucinated |
| `inspect` | allowlisted evidence targets only |
| `findings` | severity and requirements to claim a defect |
| `repair` | typed permission policy, single writer and prohibited effects |
| `verification` | objective proof conditions; unavailable ≠ PASS |
| `release` | mandatory gate behavior and status |
| `budget` | cost/attempt ceilings enforced by host runtime |

## Interpreter obligations

1. Reject unknown versions, unsupported predicates, ambiguous permission classes, malformed schemas and arbitrary executable payloads.
2. Evaluate applicability before activating checks. `UNKNOWN` cannot be silently treated as NOT_APPLICABLE when it affects mandatory controls.
3. The rule planner can request inspections or propose changes but cannot override the master safety contract.
4. The authorizer must bind permissions to `{tenant, actor, project, environment, operation, resource, expiry, max_scope}`; every tool call rechecks them server-side.
5. State-changing actions use idempotency keys and a single serialized writer per artifact. Validate claimed `changed_files` against actual diffs.
6. Evidence includes specific code revision and test environment, with hashes of non-sensitive artifacts and timestamp. A hash proves integrity of a stored artifact, not correctness of the code.
7. Release verdict is derived from mandatory gates, not a self-reported percentage. Stop on budget/time ceilings with resumable state and truthful incomplete statuses.
8. Recompile/rereview rule versions when standards or project stack changes; preserve prior run rule versions for reproducibility.
9. Never send arbitrary private repository content or user data to remote LLMs without customer consent and a declared data-processing boundary.

## Example compiler pipeline (future)

`validated FPL rules -> applicability graph -> prioritized execution DAG -> authorized tool calls -> actual patch/test evidence -> independent gate evaluation -> signed report digest`

The signing key must live on the server, not in customer prompts or the client. A signature can authenticate the issued report but **does not certify that the tests were comprehensive**.

## Minimal grammar guidance

Implementation may use versioned YAML/JSON validated with JSON Schema; prefer simple typed predicates and allowlisted actions, not free-form code evaluation. Rules may contain bounded LLM instructions as **data within a trusted system**, but the interpreter still enforces concrete permissions, budgets and evidence requirements. No general `eval`, shell commands or direct production mutations from untrusted FPL text.
