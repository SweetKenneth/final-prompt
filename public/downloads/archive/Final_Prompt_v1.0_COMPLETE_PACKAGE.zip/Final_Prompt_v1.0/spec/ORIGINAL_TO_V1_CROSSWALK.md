# Final Prompt v1.0 — Source-to-Module Crosswalk

The user's seven starting prompt specifications are the foundation of this expanded suite. This crosswalk identifies where their original sections appear and what operating changes were intentionally made. The new modules are a consolidated, edited version, **not a verbatim archive** of the source prompts.

| Original specification | Original numbered structure | Primary destination | Cross-cutting enhancement |
|---|---:|---|---|
| Backend / API Production Audit | 12 sections | FP-03 | FP-09 security, FP-10 data, FP-11 CI/CD, FP-12 operations, FP-16 integrations |
| Frontend Production Audit | 13 sections | FP-04 | FP-05 components, FP-06 SEO, FP-08 branding, FP-14 accessibility/testing |
| SEO Prompt | 12 main areas | FP-06 | FP-07 verified publisher/legal facts, FP-08 preview assets, FP-13 performance |
| Legal Prompt | 13 sections | FP-07 | Privacy data map, truth checks, human legal approval, precise IP/attribution boundaries |
| Branding Prompt | 10 sections | FP-08 | Two modes: safe brand audit vs owner-approved complete rebrand; licensing checks |
| Component Fix | 10 sections | FP-05 | Dynamic per-component invocation, evidence and regression gates |
| Universal Operational Gap Analysis | 5 phases and 20 categories | FP-01 | Initial discovery **and** final blind-spot sweep, always read-only |

## Important deliberate changes from the originals

1. **Universal safety and permission gates:** original 'implement all fixes' directives now operate within one permissions system. High-risk actions require explicit approval.
2. **One artifact owner:** SEO, frontend, branding and legal all touch metadata/footers; one coordinated owner prevents conflicting edits.
3. **No search engine mythology:** character lengths are editorial heuristics, not Google limits; `llms.txt` is optional and not a verified Google ranking factor; structured data must reflect real content.
4. **No fabricated legal claims:** an unknown customer's legal business identity, privacy practices, ownership or geographic laws cannot be assumed. PromptFluid attribution is a template only when verified for a PromptFluid-owned product.
5. **No deceptive removals:** Lovable/template remnants may be replaced for an approved rebrand while respecting applicable provider/OSS attribution requirements.
6. **No invented infrastructure:** every module has applicability rules; absent systems are `NOT_APPLICABLE`, inaccessible tests are `UNVERIFIED`.
7. **No false release certification:** 'SHIP' means scoped evidence-backed readiness, not guaranteed zero risk or endorsement by a standards body.
8. **Budget, resumability, safe parallelism:** pause at limits, checkpoint work, don't replay irreversible side effects or allow multiple agents to overwrite the same files.

## Missing disciplines introduced

FP-02 Architecture; FP-09 Security/Threat Modeling; FP-10 Data/Migration/Recovery; FP-11 Infrastructure/CI/CD/Supply Chain; FP-12 Reliability/Observability/Incident Response; FP-13 Performance/Capacity/Cost; FP-14 Tests/Accessibility/Compatibility; FP-15 Business Logic/Payments/Entitlements; FP-16 Integrations/Communications; FP-17 AI/Agent Systems; FP-18 Documentation/Support; FP-19 Independent Verification/Release Gate; FP-20 Post-Release Assurance.
