# Final Prompt MCP / REST API — Implementation Blueprint

**Status:** architecture and contract proposal; there is no live Final Prompt server, deployed endpoint, billing system, or working MCP implementation in this package.

## Product boundaries

The coding client (Lovable where MCP is supported, Claude Code, Cursor, or another authorized environment) grants scoped project access and requests a run. The Final Prompt service stores proprietary rules, risk decisions and orchestration state. An isolated authorized worker reads project code, proposes/implements patches, executes verifiers and records evidence. A separate release policy engine produces a readiness verdict. Clients see authorized findings, diff summaries, progress, artifacts and reports—not the complete rule library by default.

A remote MCP client does **not automatically** grant shell access to the customer's machine, repository write permissions, staged deployment, or data access. The connector must arrange an explicit repository integration, agent bridge or delegated workspace access and respect host capabilities.

## API authentication and tenancy

- OAuth-based client authorization for remote MCP where required by the negotiated MCP specification; use the official authorization specification appropriate to the supported version. REST callers use scoped service tokens where appropriate.
- Each request checks tenant, project, actor, operation, environment, token expiry and active entitlement. No cross-tenant logs, findings, artifacts or task state.
- Protect API keys, webhook signing secrets and report-signing keys in a server-side vault or equivalent secret store. Never ship them in MCP tool definitions or prompt text.
- Fine-grained scopes: `run:read`, `audit:execute`, `code:propose`, `code:write`, `approval:create`, `report:read`, `deploy:approve` (deployment execution separately controlled).
- User consent and documented data boundary for private source code, logging, model vendors and retention; define deletion/export paths before launch.

## Suggested MCP tool surface

| Tool | Behavior | Permissions |
|---|---|---|
| `fp_start_run` | Create a scoped job, detect baseline, return `run_id` | audit:execute |
| `fp_get_status` | Return phase, checkpoint, cost, findings counts | run:read |
| `fp_get_plan` | Retrieve module selection, risks, approval requirements | run:read |
| `fp_list_findings` | Paginated evidence-linked findings | run:read |
| `fp_continue_run` | Execute next authorized phase/limited step | audit:execute; code:write as required |
| `fp_approve_action` | Record owner-approved scoped action, never blank approval | approval:create |
| `fp_get_report` | Return signed/digested report and artifacts | report:read |
| `fp_cancel_run` | Stop new work, preserve state and safe cleanup | audit:execute |

Tool descriptions should be short and safe for model contexts. Tool results must not dump full private rules, secrets or third-party confidential source. Use immutable server-issued run IDs/approval IDs with authenticated ownership checks; never assume an ID is proof of permission.

## REST resource proposals

```text
POST   /v1/runs                create run
GET    /v1/runs/{run_id}       status and state
GET    /v1/runs/{run_id}/plan  phase graph and approvals
POST   /v1/runs/{run_id}/next  execute bounded step
GET    /v1/runs/{run_id}/findings?cursor=...&limit=...
POST   /v1/runs/{run_id}/approvals
GET    /v1/runs/{run_id}/report
POST   /v1/runs/{run_id}/cancel
```

All server paths are conceptual. Real versioning, request/response schemas, errors, pagination, CORS, OAuth flow, content-addressed artifacts, webhook signature enforcement and billing must be implemented/tested before customers can use them.

## Run lifecycle and idempotency

`CREATED -> BASELINING -> AUDITING -> PLANNED -> (AWAITING_APPROVAL) -> PATCHING -> VERIFYING -> REPORT_READY`

Terminal/paused substates: `BLOCKED`, `CANCELLED`, `BUDGET_EXHAUSTED`, `ERROR_RECOVERABLE`. An interrupted run may resume after repository revision reconciliation; never replay payment, webhook, message send, migration or other side effect without an idempotency record and explicit guard.

## Worker isolation

- Clone/checkout pinned ref into per-run sandbox/worktree, with resource/network/time limits and scoped credentials.
- Keep source private; no unrestricted internet/exfiltration, no mounting host credentials, no untrusted dependency postinstall outside controlled policy.
- Use separate read-only scanners and a serialized patch integrator; never concurrent writers on shared files.
- Execute tests in sandboxed environments and retain short-lived, redacted artifacts; safeguard malware scanner results and third-party dependencies.
- Deployment and destructive DB operations never occur from a generic 'run full audit' call.

## Metering and billing

Measure token/API calls, CPU time, storage, egress and paid external tool usage by tenant/project/run. Enforce prepaid spend/usage limits **on server**, not by a model promising to respect a dollar amount. Estimate first, notify before consuming more, pause at cap and preserve state. Account for retries and wasted attempts. Avoid billing failed/duplicate execution as successful full passes without a transparent policy.

## Release report and proofs

Use schema-based findings/evidence. Store immutable run/revision metadata, test command, safe output excerpt, tool version, exit code and status for each gate. Optionally sign the report digest and maintain append-only audit events. Explain plainly that signatures prove report integrity, not formal certification or total vulnerability absence.

## API threat model checklist

Access token audience/issuer validation, auth code flow and PKCE as applicable, token/session expiry and revocation, state/nonce handling, per-project least privilege, IDOR/tenant-bound resource lookup, replay/idempotency, zip-slip/path traversal on uploaded repos, webhook forgery, dependency execution, prompt injection from code comments, data exfiltration via LLM/tools, billing abuse, rate limits, malicious test scripts, artifact retention/deletion, log redaction, API error privacy and SOC/incident practices proportionate to the business.

## Compatibility strategy

Support the MCP version explicitly negotiated with each client; do not assume every client supports the same task/lifecycle extensions, file access or tool approval UX. Use a versioned REST service as the platform-neutral core and keep MCP as a thin adapter. Provide `fp_get_status` polling for clients lacking advanced task extension support.

## MVP acceptance criteria

1. A test client can authenticate, authorize one repository and start an isolated audit.
2. The service inventories the codebase and emits an evidence-backed 20-category applicability matrix.
3. It proposes safe changes on a branch without production writes or secret leakage.
4. It can resume a paused run, respecting budget and not replaying side effects.
5. Critical negative security tests can cause BLOCK even when lint/build pass.
6. Its API returns the same findings/approval/report states as MCP.
7. Cross-tenant API and artifact access are denied in integration tests.
8. All claims shown to the customer are tied to executed evidence and environment.
