# Final Prompt — Evidence/Data Contract Notes

These JSON Schema files are illustrative contracts for a future executor; use them for typed report interchange and test fixtures. Schemas validate **shape**, not the truth of a claim. A trusted service must verify tool provenance, repo revision, environment binding, signatures and authorization before accepting evidence.

- `run-state.schema.json`: checkpoint, mode, revision, budget, phases, owner, status.
- `finding.schema.json`: independent defect severity, location, reproduction and resolution evidence.
- `evidence.schema.json`: command/test/browser/inspection proof with exact scope.
- `release-report.schema.json`: gate coverage, verdict and risk notes.
- `approval.schema.json`: explicit actor/action/environment/resource/time-bound authorization.

Never store passwords, bearer tokens, secret env var values, raw customer datasets, full unredacted logs or privileged access URLs in these artifacts. Structured records can still be sensitive; apply access control and retention.
