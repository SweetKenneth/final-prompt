# Private Engine, Licensing and Distribution Strategy

These notes are a product design suggestion, not intellectual property or legal advice.

## What to make public

A short MCP tool surface, client integration instructions, a standard report format, example results with synthetic data, and the promise of safe, evidence-led production hardening. Customers should see which **categories** are tested, what access is required, how data is handled, and how risks are classified.

## What to keep server-side

FPL rule corpus, proprietary orchestration and triage heuristics, private evaluation fixtures, pricing/metering rules, detailed remediation templates, detection strategies, false-positive tuning and signing keys. Avoid returning the full rule text in MCP tool responses. Note that reports and emitted patches inevitably reveal some behavior; secrecy alone cannot make a product hard to imitate.

## Access and data boundaries

Private source code access is high trust. Obtain explicit authorization and document whether source reaches third-party model providers, where it is processed/stored, who can access artifacts, audit log retention, data deletion and export procedures. Make credentials short-lived and least privilege. Do not store customers' source in model training by default without specific informed opt-in and lawful basis.

## Commercial and legal readiness

Before selling, review ownership and license of original prompt text, company/trade-name trademark searches, customer terms, privacy/DPAs where applicable, subprocessors, professional liability representations, usage limits, refund terms and claim substantiation. 'Production-ready' should be described as scoped assurance based on executed verification, not perfection or guaranteed freedom from vulnerabilities.

## Product defensibility

Build value from verified results, integration into engineering workflows, conservative release decisions, transparent evidence, low false positives, reproducible benchmark results, incremental rechecks and trustworthiness. The API should stay useful even when customers use entirely different coding models.
