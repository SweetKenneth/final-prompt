#!/usr/bin/env python3
"""Local structural/specification validation for the Final Prompt package.

This is NOT a verification of a customer's code, commercial runtime, or MCP service.
"""
from pathlib import Path
import sys, hashlib, json, re

BASE=Path(__file__).resolve().parent.parent
errors=[]
def check(ok,what):
    if not ok: errors.append(what)

def rel(p): return str(p.relative_to(BASE))

# Manifest is intentionally self-excluded to avoid recursive hashes.
manif=BASE/'MANIFEST.json'
check(manif.exists(),'missing MANIFEST.json')
if manif.exists():
    m=json.loads(manif.read_text(encoding='utf-8'))
    files={x['path']:x for x in m['files']}
    found={rel(p) for p in BASE.rglob('*') if p.is_file() and p.name!='MANIFEST.json'}
    check(set(files)==found,f'manifest file set differs: missing={sorted(found-set(files))}; stale={sorted(set(files)-found)}')
    for r,x in files.items():
        p=BASE/r
        if p.is_file():
            check(p.stat().st_size==x['bytes'], f'manifest byte mismatch: {r}')
            check(hashlib.sha256(p.read_bytes()).hexdigest()==x['sha256'], f'manifest SHA256 mismatch: {r}')
    check(m['version']=='1.1.0','manifest version must be 1.1.0')
    check(m['module_count']==21,'manifest module_count must be 21')

mods=sorted((BASE/'modules').glob('*.md'))
check(len(mods)==21,f'found {len(mods)} modules instead of 21')
check([int(p.name[:2]) for p in mods]==list(range(1,22)),'module filenames not sequential 01-21')
expected={18:'FINAL_GAP_SWEEP',19:'RELEASE_GATE',20:'FOUNDERS_GUIDE',21:'GUIDE_AUDIT'}
for n,suffix in expected.items():
    check((BASE/f'modules/{n:02}_{suffix}.md').exists(),f'phase {n} must be {suffix}')

master=(BASE/'00_MASTER_PROMPT.md').read_text(encoding='utf-8')
for name in ['18_FINAL_GAP_SWEEP','19_RELEASE_GATE','20_FOUNDERS_GUIDE','21_GUIDE_AUDIT']:
    check(name in master,f'master does not mention {name}')

# Check the Owner's Manual prompt covers all canonical 18 sections.
guide=(BASE/'modules/20_FOUNDERS_GUIDE.md').read_text(encoding='utf-8')
for n in range(1,19):
    check(re.search(r'^###\s*'+str(n)+r'\.',guide,re.M) is not None,f'guide missing canonical section {n}')

# Verify simple file references to this package.
for f in BASE.rglob('*.md'):
    s=f.read_text(encoding='utf-8')
    # explicit paths inside code tags (allow human prose to mention future output files)
    for reference in re.findall(r'`((?:modules|contracts|templates)/[^`\s]+\.(?:md|json|html))`',s):
        check((BASE/reference).exists(),f'{rel(f)} references missing {reference}')

# Validate JSON Schema and example, including negative tests if jsonschema installed.
try:
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError:
    errors.append('jsonschema is not installed; cannot confirm schema conditions')
else:
    sc=json.loads((BASE/'contracts/RUN_STATE_SCHEMA.json').read_text())
    Draft202012Validator.check_schema(sc)
    validator=Draft202012Validator(sc,format_checker=FormatChecker())
    demo=json.loads((BASE/'contracts/EXAMPLE_RUN_STATE.json').read_text())
    check(not list(validator.iter_errors(demo)),'run state example rejected')
    for invalid in [
        {**demo,'tests':[{'id':'a','name':'a','status':'PASS','environment':'local','commit':'abc'}]},
        {**demo,'approvals':[{'id':'a','action':'deploy','status':'APPROVED','scope':'prod'}]}
    ]:
        check(bool(list(validator.iter_errors(invalid))),'schema accepted invalid PASS/APPROVED sample')
    gc=json.loads((BASE/'contracts/GUIDE_MANIFEST_SCHEMA.json').read_text())
    Draft202012Validator.check_schema(gc)

# Template is a scaffold; never imply it is the generated dossier.
template=(BASE/'templates/OWNERS_MANUAL_TEMPLATE.html').read_text()
for fragment in ['name="viewport"','@media print','Template only','href="#executive-summary"']:
    check(fragment in template,f'HTML design template missing {fragment}')
check('https://' not in template and '<script ' not in template,'template should not depend on external resources')

if errors:
    print('FAILED',len(errors),'checks')
    for err in errors:print(' -',err)
    sys.exit(1)
print(f'PASS: {len(mods)} modules, {len(list(BASE.rglob("*.*")))} counted files, manifest SHA256, run-state/guide schemas, safety conditional negative checks, module ordering, source references, 18 canonical sections, HTML template checks')
