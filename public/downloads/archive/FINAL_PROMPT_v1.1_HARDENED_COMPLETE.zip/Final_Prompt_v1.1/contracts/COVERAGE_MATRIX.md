# Coverage Matrix — Original Seven Modules to Final Prompt v1.1

This matrix maps each category in the seven original user-provided prompts to its primary accountable module. **Preserved in substance, expanded or adjusted for safe commercial execution**, not a verbatim reproduction.

## Original: Backend/API (12 numbered sections)

| Source topic | Primary module | Cross-check |
|---|---|---|
| 1 API correctness | 03 Backend/API | 02 Contracts, 16 Tests |
| 2 Validation and safety | 03 Backend/API | 06 Security |
| 3 Data contracts | 02 Architecture | 03 Backend, 04 Frontend |
| 4 Performance | 09 Performance | 03 Backend |
| 5 Reliability/resilience | 03 Backend/API | 11 Operations |
| 6 Security/privacy | 06 Security | 03 Backend |
| 7 Database/storage | 07 Data/recovery | 03 Backend |
| 8 Email/webhooks/integrations | 03 Backend/API | 08 Business logic |
| 9 Logging/monitoring/errors | 11 Operations | 03 Backend |
| 10 Code quality | 03 Backend/API | 02 Architecture |
| 11 Deployment/runtime | 10 Infrastructure | 17 Deployment |
| 12 Build/test/verify | 16 Tests | 19 Gate |

## Original: Frontend (13 numbered sections)

| Source topic | Primary module | Cross-check |
|---|---|---|
| 1 Functional correctness | 04 Frontend | 05 Component |
| 2 Forms/validation | 04 Frontend | 03 Backend |
| 3 State/data flow | 04 Frontend | 02 Contracts |
| 4 Web vitals/performance | 09 Performance | 04 Frontend |
| 5 Reliability/resilience | 04 Frontend | 16 Tests |
| 6 Security/privacy | 06 Security | 04 Frontend |
| 7 Accessibility | 12 Accessibility | 05 Component |
| 8 Responsive robustness | 12 Accessibility | 04 Frontend |
| 9 SEO/metadata | 13 SEO | 04 Frontend |
| 10 JSON-LD/machine assets | 13 SEO | 14 Legal |
| 11 Content/trust | 13 SEO | 14 Legal |
| 12 Code quality | 04 Frontend | 05 Component |
| 13 Build/test | 16 Tests | 19 Gate |

## Original: SEO (12 sections)

1 metadata → 13; 2 OG/social → 13 + 15; 3 schema → 13; 4 crawling → 13; 5 linking → 13; 6 headings → 13 + 12; 7 media → 13 + 09; 8 performance → 09; 9 content → 13; 10 trust → 14 + 13; 11 brand/entity → 15 + 13; 12 accessibility → 12.

**Corrections:** title/description lengths are suggestions rather than hard Google limits; `noindex` must be crawlable to be seen; robots is not authorization; `llms.txt` is optional, not a proven ranking factor.

## Original: Legal and site governance (13 sections)

1 `llms.txt` → 14 + 13; 2 footer → 14 + 04; 3 privacy → 14; 4 terms → 14; 5 disclaimers → 14; 6 robots → 13; 7 sitemap → 13; 8 schema → 13 with verified legal facts; 9 operational trust → 14; 10 copyright → 14; 11 third-party references → 14; 12 production checks → 16 + 19; 13 reporting → 19.

**Corrections:** operator-specific attribution is applied only if verified; privacy, legal and ownership statements require fact collection and human approval; no false implication of enforceable rights in broad categories like ideas or site structure.

## Original: Branding (10 sections)

1 template/Lovable audit → 15; 2 identity discovery → 15; 3 logo concept generation → 15 (full rebrand opt-in); 4 favicon/PWA → 15; 5 social images → 15; 6 metadata/manifests → 15 with 13 as writer for metadata; 7 UI consistency → 15 with 04; 8 quality → 15; 9 asset hygiene → 15; 10 verification → 16.

**Corrections:** preserve legitimate/required service attributions and third-party licensed materials; generated visuals must exist and be checked, not asserted.

## Original: Component Fix (10 sections)

1 correctness → 05; 2 runtime → 05; 3 performance → 05 + 09; 4 maintainability → 05; 5 types → 05 + 02; 6 accessibility → 05 + 12; 7 responsive → 05 + 12; 8 SEO impact → 05 + 13; 9 security → 05 + 06; 10 tests → 05 + 16.

## Original: Universal Operational Gap Analysis

Original five phases (Surface Mapping, 20 Categories, Severity Scoring, Remediation Roadmap, Blind Spot Sweep) are integrated into **01 read-only discovery** and **18 final independent read-only sweep**, with actual fixes owned by modules 02–17. All 20 gap categories appear explicitly in module 01; report coverage in module 18 and the master dossier.

## Net-new additions

02 Architecture/contract integrity; 06 deep security threat modeling; 07 data backup and restoration; 08 business logic/payments; 09 performance and cost; 10 infrastructure/CI/CD/supply chain; 11 observability/incident response; 12 dedicated accessibility; 16 independent adversarial verification; 17 staging/rollback; 19 evidenced release gate; FPL DSL; remote MCP/REST blueprint; human approval, cost caps, run checkpoints and report schema.

## Important version distinction

This suite is **a prompt and service design package**. No security audits, repo modifications, paid runs, certifications or platform integrations were executed merely by preparing these documents.


## Founder’s Guide source prompts (two further supplied originals)

- **Master Project Owner’s Manual Generation Patch** → `modules/20_FOUNDERS_GUIDE.md`: all 18 chapters, six drafting phases, architecture diagrams, facts/status labels, present and peak-value scenarios with honesty gates, private documentation, Markdown + HTML + verified PDF or PDF-ready fallback, succession and continuity.
- **Canonical Owner’s Manual Enterprise Audit & Truth Validation Patch** → `modules/21_GUIDE_AUDIT.md`: forensic truth checks, architectural consistency, valuation audit, future-operator continuity rehearsal, source/register checks, print/mobile/export validation, secure data exclusion and correction ledger.
- Both have a single private-by-default disclosure protocol in `contracts/FOUNDER_GUIDE_CONTRACT.md`. Existing product founder metadata must not contaminate customer project attribution.

## Original two Founder’s Guide source prompts (added in v1.1)

| Owner-authored requirement | Integrated prompt / contract |
|---|---|
| Definitive Owner’s Manual, source intake, 18 canonical sections | `modules/20_FOUNDERS_GUIDE.md` |
| Architecture maps, roadmap, valuation scenarios, continuity/inheritance | `modules/20_FOUNDERS_GUIDE.md` + `contracts/FOUNDER_GUIDE_CONTRACT.md` |
| Professional Markdown/HTML/PDF-ready presentation with truthful export status | `modules/20_FOUNDERS_GUIDE.md` + `templates/OWNERS_MANUAL_TEMPLATE.html` |
| Forensic claims/architecture/inventory/roadmap/valuation audit | `modules/21_GUIDE_AUDIT.md` |
| Secrets/redaction, mobile/print QA, continuity and buyer utility audit | `modules/21_GUIDE_AUDIT.md` + `contracts/FOUNDER_GUIDE_REPORT_TEMPLATE.md` |
| Founder attribution supplied for **Final Prompt** (not customers) | `contracts/FINAL_PROMPT_FOUNDER_METADATA.md`, opt-in confirmation |

**Separation:** The software release verdict comes from `19_RELEASE_GATE`; the private guide distribution verdict comes from `21_GUIDE_AUDIT`. They must never overwrite or imply each other.
