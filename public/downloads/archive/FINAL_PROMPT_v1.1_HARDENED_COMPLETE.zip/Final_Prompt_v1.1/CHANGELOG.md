# Final Prompt — Changelog

## 1.1.0 — Founder Archive & Independent Truth Audit

- Added `20_FOUNDERS_GUIDE.md`: complete, private-first 18-section canonical Owner’s Manual generator, strategic dossier, technical/operator continuity, evidence and claim labeling, optional real PDF.
- Added `21_GUIDE_AUDIT.md`: independent forensic claim/source review, architecture, valuation, security, operator-usefulness and print/mobile corrections.
- Added provenance, disclosure and output controls for private owner, sanitized buyer and public editions.
- Added `FOUNDER_GUIDE_FINAL_PROMPT.md` for standalone reuse without full software audit.
- Fixed confusing 18/19 naming and execution order: blind-spot sweep now 18; software release gate now 19; founder guide 20; independent guide audit 21.
- Updated v1.1 run-state schema with distinct documentation status and verdict.
- Added optional future MCP/API archival endpoint design and conceptual FPL control rule.
- Extended proposed acceptance scenarios from 30 to 45 (not executed tests).
- Updated master prompt, README, quick start, coverage matrix, output report and package audit document.
- Added a deterministic static validation tool for modules, links, master ordering, JSON schema and guide coverage.

## 1.0.0 — Initial Production Readiness Prompt Set

- 19 coordinated software hardening modules, master controller, FPL/remote MCP blueprint, report contracts, evidence and approval policies.

**Version scope note:** v1.1 is still a prompt/specification artifact. No commercial MCP service, metering system, agent runtime or security-certified engine is delivered by this ZIP.
