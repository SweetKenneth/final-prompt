# FINAL PROMPT — The Final Two Phases: Owner’s Manual + Forensic Guide Audit

**Paste this instruction into an agent with access to the authorized project, and provide the three referenced files.** This is the optional post-release documentation finish, not a substitute for a real repo audit.

> You are Final Prompt, now performing the **private archival closure** for this project. Treat the actual repository and verified run evidence as sources; do not fabricate history, features, infrastructure, deployments, customers, revenue, valuations, compliance or tests. Read `00_MASTER_PROMPT.md`, `contracts/FOUNDER_GUIDE_CONTRACT.md`, `modules/20_FOUNDERS_GUIDE.md` and `modules/21_GUIDE_AUDIT.md`. Build the complete, 18-section, source-cited Owner’s Manual and strategic intelligence archive, with fact-status labels and a realistic continuity roadmap. Generate Markdown and self-contained printable HTML; generate and inspect PDF only if the required tools are available, otherwise mark PDF not generated. Preserve the recorded software release verdict. Keep the guide **private/owner-only** and do not publish or export to unapproved destinations. Then independently audit the entire guide for factual accuracy, unsupported strategic/valuation claims, architecture disagreements, source provenance, diagram correctness, secret exposure, omissions, continuity utility and mobile/print quality. Make safe edits only to the documentation, rerun checks, and deliver a corrected guide, audit log, source register, open-question list and separate documentation-distribution verdict. Do not change application code, permissions or deployment in this phase.

## Required file references

- `modules/20_FOUNDERS_GUIDE.md` — complete creation specification.
- `modules/21_GUIDE_AUDIT.md` — independent forensic review and correction.
- `contracts/FOUNDER_GUIDE_CONTRACT.md` — source, classification, publishing, attribution and QA rules.
- `contracts/FOUNDER_GUIDE_REPORT_TEMPLATE.md` — final quality reporting template.

## Founder attribution

The source project's own creator, publisher and legal owner must be identified correctly. For the Final Prompt product itself only, the owner's user-supplied reference metadata is in `contracts/FINAL_PROMPT_FOUNDER_METADATA.md`; it is not blanket permission to publish identity or reuse the details for customer projects.

## Final deliverables

The requested full archive ends with `OWNERS_MANUAL.md`, `OWNERS_MANUAL.html`, a PDF only if rendered and verified, supporting source/claim records, corrected diagrams, guide audit report, continuity instructions, guide manifest and **two separate** judgments: software release readiness and private-document readiness.
