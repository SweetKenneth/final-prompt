# FINAL PROMPT — Production Readiness Protocol v1.1

**Tagline:** Build with anything. Finish with Final Prompt.

**Package status:** Complete prompt/specification set; NOT a deployed MCP service, functioning execution engine, tested certification platform, or substitute for professional security/legal review.

## Start here

1. **For an AI coding agent today:** Copy `00_MASTER_PROMPT.md` into a coding agent with repository access. It instructs the agent to read the appropriate module prompts, begin with a read-only inventory, and work in checkpoints. Copy `QUICKSTART.md` when you need a short startup instruction.
2. **For one targeted task:** Use the relevant standalone file in `modules/`. Each module includes its own execution contract.
3. **For an eventual commercial MCP/API product:** Use `contracts/MCP_API_PRODUCT_SPEC.md`, `contracts/FPL_SPEC.md`, and the schemas and safety specification as an implementation blueprint. The MCP service is **not implemented** in this package. The owner documentation generator and auditor are prompt specifications, not a generated manual for any particular app.
4. **To deliver a report:** Use `contracts/REPORT_TEMPLATE.md` and persist the run ledger specified in `contracts/RUN_STATE_SCHEMA.json`.
5. **For the final owner archive:** Run `modules/20_FOUNDERS_GUIDE.md` and then `modules/21_GUIDE_AUDIT.md`, with `contracts/FOUNDER_GUIDE_CONTRACT.md`. Keep this private unless a specific distribution is authorized.

## Original user-authored source modules, integrated and expanded

| Origin | Integrated module |
|---|---|
| Backend/API production audit | `modules/03_BACKEND_API.md` |
| Frontend production audit | `modules/04_FRONTEND.md` |
| SEO implementation | `modules/13_SEO_MACHINE_READABILITY.md` |
| Legal/site governance | `modules/14_LEGAL_GOVERNANCE.md` |
| Branding replacement | `modules/15_BRANDING.md` |
| Component fix | `modules/05_COMPONENT.md` |
| Universal operational gap analysis (20 categories) | `modules/01_GAP_ANALYSIS.md` and `modules/18_FINAL_GAP_SWEEP.md` |
| Canonical Project Owner’s Manual | `modules/20_FOUNDERS_GUIDE.md` |
| Owner’s Manual forensic truth/enterprise audit | `modules/21_GUIDE_AUDIT.md` |

The original seven technical prompt families and two Founder’s Guide prompts were normalized into coordinated prompts, with the key scopes and constraints retained. This is an **edited and expanded** edition, not a verbatim archive of the originals.

## Complete 21-phase suite

`01` Gap discovery → `02` Architecture → `03` Backend → `04` Frontend → `05` Components → `06` Security → `07` Data/recovery → `08` Business logic → `09` Performance → `10` Infrastructure/CI/CD → `11` Observability → `12` Accessibility → `13` SEO/machine readability → `14` Legal/governance → `15` Branding → `16` Independent testing → `17` Deployment/rollback → `18` Final gap sweep → `19` Software release gate → `20` Founder’s Owner Manual → **`21` Independent guide audit (the final prompt).**

The master controller is free to reorder **applicable** implementation phases according to dependencies and risk. Gap discovery must run first, final blind-spot sweep before release gate, then the owner guide and independent guide audit when archival mode is selected, and verification must follow any relevant changes. Some phases (e.g., payments, SEO, branding) do not apply to every project.

## What Final Prompt promises (and does not)

- Audit the software that **exists**. Do not hallucinate features, frameworks, credentials, database instances, hosting, or legal obligations.
- Implement **safe, authorized** repairs on an isolated branch, with minimal diffs and regression tests; produce evidence.
- Identify high-risk changes and request explicit human authorization, or leave them blocked with clear next steps.
- Never mark a check passed without running it or observing authoritative evidence. A lint pass does not prove security, and a build pass does not prove readiness.
- Never guarantee that a website or app is entirely secure, legally compliant, inaccessible to attackers, or free of defects.
- Read-only audits are valid and produce a plan without changes. Any tool-free environment should be reported as such, not described as having made changes.


## Founder’s Guide — the final two phases

**20 / Canonical Owner’s Manual Generator:** Produces an archival, confidential project dossier with 18 required sections, source register, claims ledger, architecture maps, history, roadmap, risks, economic scenarios, continuity instructions and a print-ready HTML/Markdown publication layer. It does not invent deployment, customers, revenue, ownership or valuations.

**21 / Enterprise Guide Audit:** Cross-checks each material claim against actual source evidence, tests diagrams and internal links, checks secret redaction and private/public editions, inspects rendered output where tools permit, and records the distinct **documentation distribution status**. This is the last prompt in the package.

Guide contracts: `contracts/FOUNDER_GUIDE_CONTRACT.md`, `contracts/FOUNDER_GUIDE_REPORT_TEMPLATE.md`, `contracts/FINAL_PROMPT_FOUNDER_METADATA.md` (Final Prompt's internal dossier only, not customer templates). Optionally use `templates/OWNERS_MANUAL_TEMPLATE.html` as a starting design; a blank template is not a finished guide.

**Confidential by default:** Do not commit founder dossiers, internal architecture, vulnerabilities, or succession instructions to an unapproved repository or expose them through web search, llms.txt, sitemaps, PDF metadata, or public MCP artifact endpoints.

## Project governance

Brand replacement is **opt-in**, and removal of third-party credits must honor contracts/licenses. Legal policies are drafts until fact-checked and approved by the operator/counsel. Terms/Privacy should never claim data isn't sold, or that cookies are absent, without confirming practices. `llms.txt` is optional and not a Google ranking guarantee. SEO character targets are not hard limits. `robots.txt` does not protect private resources and may prevent crawlers from seeing `noindex`.

## References (verify against latest official versions before implementation)

- OWASP ASVS 5.0.0: https://asvs.owasp.org/
- NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final
- MCP specification release (2026-07-28): https://blog.modelcontextprotocol.io/posts/2026-07-28/
- Google Search Central, `noindex`: https://developers.google.com/search/docs/crawling-indexing/block-indexing
- Google Search Central, snippets: https://developers.google.com/search/docs/appearance/snippet
- WCAG 2.2: https://www.w3.org/TR/WCAG22/

## Suggested project file ownership

- Backend → server handlers/contracts; Security → cross-cutting security controls, with backend integration reviewed jointly.
- SEO → canonical metadata, sitemap, robots, structured data; Legal → wording/policy/disclosures; Branding → approved imagery and tokens; Frontend → presentation and integration of approved artifacts.
- A **single writer** owns any shared file at a time. Dependent reviewers can request changes but may not clobber another module's work.

**Version:** 1.1.0 | **Prepared:** 2026-11-03 | **Owner:** Intended for the Final Prompt product concept.

## Packaging note

The MCP/API and FPL contracts remain designs, not a deployed API, interpreter, authentication provider, hosted job engine, or production security certification. See `AUDIT_V1.0_TO_V1.1.md` for actual reviewed changes and outstanding engineering work.
