# FINAL PROMPT — Production Readiness Protocol v1.0

**Tagline:** Build with anything. Finish with Final Prompt.

**Package status:** Complete prompt/specification set; NOT a deployed MCP service, functioning execution engine, tested certification platform, or substitute for professional security/legal review.

## Start here

1. **For an AI coding agent today:** Copy `00_MASTER_PROMPT.md` into a coding agent with repository access. It instructs the agent to read the appropriate module prompts, begin with a read-only inventory, and work in checkpoints. Copy `QUICKSTART.md` when you need a short startup instruction.
2. **For one targeted task:** Use the relevant standalone file in `modules/`. Each module includes its own execution contract.
3. **For an eventual commercial MCP/API product:** Use `contracts/MCP_API_PRODUCT_SPEC.md`, `contracts/FPL_SPEC.md`, and the schemas and safety specification as an implementation blueprint. The MCP service is **not implemented** in this package.
4. **To deliver a report:** Use `contracts/REPORT_TEMPLATE.md` and persist the run ledger specified in `contracts/RUN_STATE_SCHEMA.json`.

## Original user-authored source modules, integrated and expanded

| Origin | Integrated module |
|---|---|
| Backend/API production audit | `modules/03_BACKEND_API.md` |
| Frontend production audit | `modules/04_FRONTEND.md` |
| SEO implementation | `modules/13_SEO_MACHINE_READABILITY.md` |
| Legal/site governance | `modules/14_LEGAL_GOVERNANCE.md` |
| Branding replacement | `modules/15_BRANDING.md` |
| Component fix | `modules/05_COMPONENT.md` |
| Universal operational gap analysis (20 categories) | `modules/01_GAP_ANALYSIS.md` and `modules/19_FINAL_GAP_SWEEP.md` |

All seven were normalized into coordinated prompts, with the key scopes and constraints retained. This is an **edited and expanded** edition, not a verbatim archive of the originals.

## Complete phased suite

`01` Discovery/gaps → `02` Architecture/contracts → `03` Backend → `04` Frontend → `05` Components → `06` Security → `07` Data/recovery → `08` Business logic/payments → `09` Performance/scaling → `10` Infrastructure/CI/CD/supply chain → `11` Observability/operations → `12` Accessibility/cross-device → `13` SEO/machine readability → `14` Legal/governance → `15` Branding → `16` Automated/adversarial verification → `17` Deployment/rollback → `18` Final release gate → `19` Final blind-spot sweep.

The master controller is free to reorder **applicable** implementation phases according to dependencies and risk. Gap discovery must run first, release gate and blind-spot sweep last, and verification must follow any relevant changes. Some phases (e.g., payments, SEO, branding) do not apply to every project.

## What Final Prompt promises (and does not)

- Audit the software that **exists**. Do not hallucinate features, frameworks, credentials, database instances, hosting, or legal obligations.
- Implement **safe, authorized** repairs on an isolated branch, with minimal diffs and regression tests; produce evidence.
- Identify high-risk changes and request explicit human authorization, or leave them blocked with clear next steps.
- Never mark a check passed without running it or observing authoritative evidence. A lint pass does not prove security, and a build pass does not prove readiness.
- Never guarantee that a website or app is entirely secure, legally compliant, inaccessible to attackers, or free of defects.
- Read-only audits are valid and produce a plan without changes. Any tool-free environment should be reported as such, not described as having made changes.

## Project governance

Brand replacement is **opt-in**, and removal of third-party credits must honor contracts/licenses. Legal policies are drafts until fact-checked and approved by the operator/counsel. Terms/Privacy should never claim data isn't sold, or that cookies are absent, without confirming practices. `llms.txt` is optional and not a Google ranking guarantee. SEO character targets are not hard limits. `robots.txt` does not protect private resources and may prevent crawlers from seeing `noindex`.

## References (verify against latest official versions before implementation)

- OWASP ASVS 5.0.0: https://asvs.owasp.org/
- NIST SSDF SP 800-218: https://csrc.nist.gov/pubs/sp/800/218/final
- MCP specification release (2026-07-28): https://blog.modelcontextprotocol.io/posts/2026-07-28/
- Google Search Central, `noindex`: https://developers.google.com/search/docs/crawling-indexing/block-indexing
- Google Search Central, snippets: https://developers.google.com/search/docs/appearance/snippet
- WCAG 2.2: https://www.w3.org/TR/WCAG22/

## Suggested project file ownership

- Backend → server handlers/contracts; Security → cross-cutting security controls, with backend integration reviewed jointly.
- SEO → canonical metadata, sitemap, robots, structured data; Legal → wording/policy/disclosures; Branding → approved imagery and tokens; Frontend → presentation and integration of approved artifacts.
- A **single writer** owns any shared file at a time. Dependent reviewers can request changes but may not clobber another module's work.

**Version:** 1.0.0 | **Prepared:** 2026-11-03 | **Owner:** Intended for the Final Prompt product concept.
